# Block Puzzle

Простая игра в стиле Block Blast для Android: перетаскивай фигуры на поле 8×8 и собирай полные линии.

## Возможности

- Поле 8×8, три фигуры в лотке, 27 вариантов фигур
- Комбо и очки за несколько линий сразу
- Подсветка линий, которые сгорят после установки фигуры
- Рекорд и текущая партия сохраняются: игру можно закрыть и продолжить
- Вибрация, анимации, частицы

## Сборка

Любой push в `main` запускает GitHub Actions:
вкладка **Actions → Build APK → Artifacts → BlockPuzzle-apk**.

Локально (нужны JDK 17 и Android SDK):

```
gradle assembleDebug
```

APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Структура

- `app/src/main/java/com/example/blockpuzzle/GameView.java` — вся игра: логика, ввод, отрисовка
- `app/src/main/java/com/example/blockpuzzle/MainActivity.java` — запуск и сохранение партии
