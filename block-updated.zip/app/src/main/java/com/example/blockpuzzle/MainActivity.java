package com.example.blockpuzzle;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Сохраняем партию и настройки: если система закроет приложение в фоне, игру можно будет продолжить.
        gameView.saveState();
    }

    @Override
    public void onBackPressed() {
        // Из игры и настроек «Назад» ведёт в меню, из меню — выход из приложения.
        if (!gameView.onBack()) super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gameView.release();
    }
}
