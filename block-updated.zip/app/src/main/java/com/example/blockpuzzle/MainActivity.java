package com.example.blockpuzzle;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Сохраняем партию: если система закроет приложение в фоне, игру можно будет продолжить.
        gameView.saveState();
    }
}
