package com.example.blockpuzzle;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends View {
    private static final int N = 8;

    private static final String[][] SHAPES = {
            {"#"}, {"##"}, {"###"}, {"####"}, {"#####"},
            {"#", "#"}, {"#", "#", "#"}, {"#", "#", "#", "#"}, {"#", "#", "#", "#", "#"},
            {"##", "##"}, {"###", "###", "###"},
            {"#.", "#.", "##"}, {"..#", "..#", "###"}, {"###", "#..", "#.."}, {"###", "..#", "..#"},
            {"##", "#."}, {"##", ".#"}, {"#.", "##"}, {".#", "##"},
            {"##.", ".##"}, {".##", "##."}, {"#.", "##", ".#"}, {".#", "##", "#."},
            {"###", ".#."}, {".#.", "###"}, {"#.", "##", "#."}, {".#", "##", ".#"}
    };

    private static final int[] COLORS = {
            0xFFFF5C7A, 0xFF4DA3FF, 0xFF3DDC97, 0xFFFFC857,
            0xFFB07CFF, 0xFFFF8F4D, 0xFF2FE0E0
    };

    private static final long IDLE_FRAME_MS = 66; // ~15 fps, когда на экране ничего не движется кроме фона

    private static class Piece { int[][] cells; int w, h, color, shape; }
    private static class Ghost { int r, c, color; long start; }
    private static class Particle { float x0, y0, vx, vy, size, life; long t0; int color; }
    private static class FloatText { String s; float x, y, size; long start; int color; }

    private final Random rnd = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint();
    private final RectF rect = new RectF();
    private final SharedPreferences prefs;

    private int[][] grid = new int[N][N];
    private final long[][] popStart = new long[N][N];
    private final boolean[][] tmp = new boolean[N][N];
    private final Piece[] tray = new Piece[3];
    private final long[] slotStart = new long[3];
    private final List<Ghost> ghosts = new ArrayList<>();
    private final List<Particle> parts = new ArrayList<>();
    private final List<FloatText> texts = new ArrayList<>();

    // результат computeTarget(): клетка поля, в которую «целится» перетаскиваемая фигура
    private int tgtR, tgtC;
    private final boolean[] rowFull = new boolean[N];
    private final boolean[] colFull = new boolean[N];

    private int score, best, combo;
    private float dispScore;
    private long bumpStart, lastFrame, shakeStart, gameOverStart, lastPlaceTime, trayAnimUntil;
    private float shakeAmp;
    private boolean gameOver, newRecord;

    private int dragIdx = -1, retIdx = -1;
    private float dragX, dragY, retX, retY, retSize;
    private long dragStart, retStart;
    private float cell, gridX, gridY, trayTop, trayCell, trayCy;

    public GameView(Context context) {
        super(context);
        setKeepScreenOn(true);
        prefs = context.getSharedPreferences("blockpuzzle", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        if (!restoreState()) newGame(SystemClock.uptimeMillis());
    }

    // ---------- save / restore ----------
    /** Сохраняет текущую партию. Вызывается из Activity.onPause(). */
    public void saveState() {
        SharedPreferences.Editor ed = prefs.edit();
        if (gameOver) {
            ed.remove("grid").remove("tray").remove("score").remove("combo");
        } else {
            StringBuilder g = new StringBuilder(N * N);
            for (int r = 0; r < N; r++)
                for (int c = 0; c < N; c++) g.append((char) ('0' + grid[r][c]));
            StringBuilder t = new StringBuilder();
            for (int i = 0; i < 3; i++) {
                if (i > 0) t.append(',');
                t.append(tray[i] == null ? "-" : tray[i].shape + ":" + tray[i].color);
            }
            ed.putString("grid", g.toString())
                    .putString("tray", t.toString())
                    .putInt("score", score)
                    .putInt("combo", combo);
        }
        ed.apply(); // рекорд пишется отдельно, в checkGameOver()
    }

    /** Восстанавливает партию; возвращает false, если сохранения нет или оно повреждено. */
    private boolean restoreState() {
        try {
            String g = prefs.getString("grid", null);
            String t = prefs.getString("tray", null);
            if (g == null || t == null || g.length() != N * N) return false;
            int[][] ng = new int[N][N];
            for (int i = 0; i < N * N; i++) {
                int v = g.charAt(i) - '0';
                if (v < 0 || v > COLORS.length) return false;
                ng[i / N][i % N] = v;
            }
            String[] slots = t.split(",");
            if (slots.length != 3) return false;
            Piece[] np = new Piece[3];
            boolean any = false;
            for (int i = 0; i < 3; i++) {
                if (slots[i].equals("-")) continue;
                String[] sc = slots[i].split(":");
                int shape = Integer.parseInt(sc[0]), color = Integer.parseInt(sc[1]);
                if (shape < 0 || shape >= SHAPES.length || color < 1 || color > COLORS.length) return false;
                np[i] = makePiece(shape, color);
                any = true;
            }
            if (!any) return false;

            grid = ng;
            for (int i = 0; i < 3; i++) {
                tray[i] = np[i];
                slotStart[i] = 0; // фигуры уже на месте, без анимации появления
            }
            for (long[] row : popStart) Arrays.fill(row, 0);
            ghosts.clear();
            parts.clear();
            texts.clear();
            score = Math.max(0, prefs.getInt("score", 0));
            dispScore = score;
            combo = Math.max(0, prefs.getInt("combo", 0));
            gameOver = false;
            newRecord = false;
            dragIdx = -1;
            retIdx = -1;
            if (!anyFits()) { // сохранение «зашло в тупик» — начинаем заново
                return false;
            }
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float easeOutCubic(float t) { float u = 1 - t; return 1 - u * u * u; }
    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1, u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }
    private static int darken(int c) {
        int r = (int) (((c >> 16) & 255) * 0.6f), g = (int) (((c >> 8) & 255) * 0.6f), b = (int) ((c & 255) * 0.6f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
    private static int mix(int a, int b, float t) {
        int r = (int) lerp((a >> 16) & 255, (b >> 16) & 255, t);
        int g = (int) lerp((a >> 8) & 255, (b >> 8) & 255, t);
        int bl = (int) lerp(a & 255, b & 255, t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------- game logic ----------
    private void newGame(long now) {
        grid = new int[N][N];
        for (long[] row : popStart) Arrays.fill(row, 0);
        ghosts.clear();
        parts.clear();
        texts.clear();
        score = 0;
        dispScore = 0;
        combo = 0;
        gameOver = false;
        newRecord = false;
        dragIdx = -1;
        retIdx = -1;
        dealPieces(now);
    }

    private void dealPieces(long now) {
        for (int attempt = 0; attempt < 30; attempt++) {
            for (int i = 0; i < 3; i++) tray[i] = randomPiece();
            if (anyFits()) break;
        }
        for (int i = 0; i < 3; i++) slotStart[i] = now + 120 + i * 110L;
        trayAnimUntil = now + 120 + 2 * 110L + 450;
    }

    private Piece randomPiece() {
        return makePiece(rnd.nextInt(SHAPES.length), 1 + rnd.nextInt(COLORS.length));
    }

    private Piece makePiece(int shapeIdx, int color) {
        String[] shape = SHAPES[shapeIdx];
        List<int[]> list = new ArrayList<>();
        int w = 0;
        for (int r = 0; r < shape.length; r++) {
            w = Math.max(w, shape[r].length());
            for (int c = 0; c < shape[r].length(); c++) {
                if (shape[r].charAt(c) == '#') list.add(new int[]{r, c});
            }
        }
        Piece p = new Piece();
        p.cells = list.toArray(new int[0][]);
        p.w = w;
        p.h = shape.length;
        p.color = color;
        p.shape = shapeIdx;
        return p;
    }

    private boolean canPlace(Piece p, int r, int c) {
        for (int[] cl : p.cells) {
            int rr = r + cl[0], cc = c + cl[1];
            if (rr < 0 || rr >= N || cc < 0 || cc >= N || grid[rr][cc] != 0) return false;
        }
        return true;
    }

    private boolean anyFits() {
        for (Piece p : tray) {
            if (p == null) continue;
            for (int r = 0; r < N; r++)
                for (int c = 0; c < N; c++)
                    if (canPlace(p, r, c)) return true;
        }
        return false;
    }

    /** Вычисляет клетку поля под перетаскиваемой фигурой и кладёт её в tgtR / tgtC. */
    private void computeTarget(Piece p) {
        float ox = dragX - p.w * cell / 2f;
        float oy = dragY - cell * 1.5f - p.h * cell / 2f;
        tgtR = Math.round((oy - gridY) / cell);
        tgtC = Math.round((ox - gridX) / cell);
    }

    private void addText(String s, float x, float y, float size, int color, long now) {
        FloatText f = new FloatText();
        f.s = s; f.x = x; f.y = y; f.size = size; f.color = color; f.start = now;
        texts.add(f);
    }

    private void placeDragged(long now) {
        Piece p = tray[dragIdx];
        computeTarget(p);
        final int tr = tgtR, tc = tgtC;
        if (!canPlace(p, tr, tc)) {
            float e = easeOutCubic(clamp01((now - dragStart) / 160f));
            float sx = getWidth() / 3f * (dragIdx + 0.5f);
            retX = lerp(sx, dragX, e);
            retY = lerp(trayCy, dragY, e) - cell * 1.5f * e;
            retSize = lerp(trayCell, cell, e);
            retStart = now;
            retIdx = dragIdx;
            return;
        }
        for (int[] cl : p.cells) {
            grid[tr + cl[0]][tc + cl[1]] = p.color;
            popStart[tr + cl[0]][tc + cl[1]] = now;
        }
        lastPlaceTime = now;
        tray[dragIdx] = null;
        int gained = p.cells.length;
        int lines = clearLines(now);
        float px = gridX + (tc + p.w / 2f) * cell;
        float py = gridY + (tr + p.h / 2f) * cell;
        if (lines > 0) {
            combo++;
            gained += lines * lines * 10 + (combo - 1) * 5;
            String label = lines >= 3 ? "Потрясающе!" : lines == 2 ? "Отлично!" : combo >= 2 ? "Комбо x" + combo : null;
            if (label != null) addText(label, getWidth() / 2f, gridY + N * cell * 0.42f, cell * 0.8f, 0xFFFFD866, now);
            if (lines >= 2) {
                shakeStart = now;
                shakeAmp = cell * 0.09f * Math.min(lines, 4);
            }
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        } else {
            combo = 0;
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
        score += gained;
        bumpStart = now;
        addText("+" + gained, px, py, cell * 0.55f, 0xFFFFFFFF, now);
        if (tray[0] == null && tray[1] == null && tray[2] == null) dealPieces(now);
        checkGameOver(now);
    }

    private int clearLines(long now) {
        boolean[] rows = new boolean[N];
        boolean[] cols = new boolean[N];
        int lines = 0;
        for (int i = 0; i < N; i++) {
            rows[i] = true;
            cols[i] = true;
            for (int j = 0; j < N; j++) {
                if (grid[i][j] == 0) rows[i] = false;
                if (grid[j][i] == 0) cols[i] = false;
            }
            if (rows[i]) lines++;
            if (cols[i]) lines++;
        }
        if (lines == 0) return 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (!(rows[i] || cols[j])) continue;
                int v = grid[i][j];
                if (v == 0) continue;
                float d = Math.min(rows[i] ? j : 99, cols[j] ? i : 99) * 24f;
                Ghost g = new Ghost();
                g.r = i; g.c = j; g.color = v; g.start = now + (long) d;
                ghosts.add(g);
                float cx = gridX + (j + 0.5f) * cell, cy = gridY + (i + 0.5f) * cell;
                for (int k = 0; k < 5; k++) {
                    Particle q = new Particle();
                    float ang = rnd.nextFloat() * 6.2832f;
                    float sp = cell * (1.5f + rnd.nextFloat() * 4f);
                    q.x0 = cx; q.y0 = cy;
                    q.vx = (float) Math.cos(ang) * sp;
                    q.vy = (float) Math.sin(ang) * sp - cell * 2f;
                    q.size = cell * (0.07f + rnd.nextFloat() * 0.12f);
                    q.t0 = g.start;
                    q.life = 0.55f + rnd.nextFloat() * 0.5f;
                    q.color = mix(COLORS[v - 1], 0xFFFFFFFF, 0.25f);
                    parts.add(q);
                }
                grid[i][j] = 0;
            }
        }
        return lines;
    }

    private void checkGameOver(long now) {
        if (anyFits()) return;
        gameOver = true;
        gameOverStart = now + 700;
        newRecord = score > best && score > 0;
        if (newRecord) {
            best = score;
            prefs.edit().putInt("best", best).apply();
        }
    }

    // ---------- input ----------
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cell = Math.min(w * 0.94f / N, h * 0.5f / N);
        gridX = (w - N * cell) / 2f;
        gridY = h * 0.18f;
        trayTop = gridY + N * cell;
        trayCell = Math.min(cell * 0.62f, (w / 3f) * 0.9f / 5f);
        trayCy = trayTop + (h - trayTop) / 2f;
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF0C1030, 0xFF2B1A55, Shader.TileMode.CLAMP));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        long now = SystemClock.uptimeMillis();
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (gameOver) {
                    if (now > gameOverStart + 500) newGame(now);
                    return true;
                }
                if (y > trayTop) {
                    int i = Math.max(0, Math.min(2, (int) (x / (getWidth() / 3f))));
                    if (tray[i] != null && now >= slotStart[i]) {
                        dragIdx = i;
                        dragX = x;
                        dragY = y;
                        dragStart = now;
                        if (retIdx == i) retIdx = -1;
                    }
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragIdx >= 0) { dragX = x; dragY = y; }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragIdx >= 0) {
                    dragX = x;
                    dragY = y;
                    placeDragged(now);
                    dragIdx = -1;
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragIdx = -1;
                return true;
        }
        return super.onTouchEvent(e);
    }

    // ---------- drawing ----------
    private void drawFlat(Canvas c, float left, float top, float size, int color, int alpha) {
        float pad = size * 0.06f, r = size * 0.2f;
        paint.setColor(color);
        paint.setAlpha(alpha);
        rect.set(left + pad, top + pad, left + size - pad, top + size - pad);
        c.drawRoundRect(rect, r, r, paint);
    }

    private void drawBlock(Canvas c, float left, float top, float size, int color, int alpha) {
        float pad = size * 0.06f, r = size * 0.2f;
        paint.setColor(darken(color));
        paint.setAlpha(alpha);
        rect.set(left + pad, top + pad, left + size - pad, top + size - pad);
        c.drawRoundRect(rect, r, r, paint);
        paint.setColor(color);
        paint.setAlpha(alpha);
        rect.set(left + pad, top + pad, left + size - pad, top + size - pad - size * 0.08f);
        c.drawRoundRect(rect, r, r, paint);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha((int) (alpha * 0.35f));
        rect.set(left + pad + size * 0.12f, top + pad + size * 0.07f,
                left + size - pad - size * 0.12f, top + pad + size * 0.07f + size * 0.15f);
        c.drawRoundRect(rect, r * 0.6f, r * 0.6f, paint);
    }

    private void drawPieceCentered(Canvas c, Piece p, float cx, float cy, float size, int alpha) {
        float left = cx - p.w * size / 2f, top = cy - p.h * size / 2f;
        for (int[] cl : p.cells)
            drawBlock(c, left + cl[1] * size, top + cl[0] * size, size, COLORS[p.color - 1], alpha);
    }

    private void drawOrbs(Canvas c, long now, int w, int h) {
        for (int k = 0; k < 5; k++) {
            float fx = (k * 0.37f + 0.1f) % 1f, fy = (k * 0.61f + 0.05f) % 1f;
            float cx = w * (0.1f + 0.8f * fx) + (float) Math.sin(now / 3500.0 + k) * w * 0.08f;
            float cy = h * (0.1f + 0.8f * fy) + (float) Math.cos(now / 4300.0 + k * 1.7) * h * 0.03f;
            paint.setColor(COLORS[k]);
            paint.setAlpha(24);
            c.drawCircle(cx, cy, w * (0.22f + 0.06f * (k % 3)), paint);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        dispScore += (score - dispScore) * Math.min(1f, dt * 9f);
        if (Math.abs(score - dispScore) < 0.6f) dispScore = score;
        int w = getWidth(), h = getHeight();
        paint.setStyle(Paint.Style.FILL);

        canvas.drawRect(0, 0, w, h, bg);
        drawOrbs(canvas, now, w, h);

        canvas.save();
        if (now - shakeStart < 380) {
            float t = (now - shakeStart) / 380f;
            canvas.translate(shakeAmp * (float) Math.sin(t * 50) * (1 - t),
                    shakeAmp * (float) Math.cos(t * 43) * (1 - t));
        }

        // HUD
        text.setColor(0xFFFFFFFF);
        text.setAlpha(150);
        text.setLetterSpacing(0.25f);
        text.setTextSize(cell * 0.32f);
        canvas.drawText("СЧЁТ", w / 2f, gridY * 0.36f, text);
        text.setLetterSpacing(0f);
        float bump = 1f + 0.2f * (float) Math.sin(Math.PI * clamp01((now - bumpStart) / 260f));
        text.setColor(0xFFFFFFFF);
        text.setTextSize(cell * 1.2f * bump);
        canvas.drawText(String.valueOf(Math.round(dispScore)), w / 2f, gridY * 0.76f, text);
        text.setColor(0xFFFFD866);
        text.setAlpha(210);
        text.setTextSize(cell * 0.34f);
        canvas.drawText("Рекорд  " + Math.max(best, score), w / 2f, gridY * 0.94f, text);

        // grid panel
        paint.setColor(0xFF141838);
        paint.setAlpha(255);
        float m = cell * 0.14f;
        rect.set(gridX - m, gridY - m, gridX + N * cell + m, gridY + N * cell + m);
        canvas.drawRoundRect(rect, cell * 0.35f, cell * 0.35f, paint);

        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                float left = gridX + c * cell, top = gridY + r * cell;
                drawFlat(canvas, left, top, cell, 0xFF222851, 255);
                int v = grid[r][c];
                if (v == 0) continue;
                float s = 1f;
                long ps = popStart[r][c];
                if (ps > 0) {
                    float t = clamp01((now - ps) / 280f);
                    if (t < 1f) s = 0.55f + 0.45f * easeOutBack(t);
                }
                float sz = cell * s;
                drawBlock(canvas, left + (cell - sz) / 2f, top + (cell - sz) / 2f, sz, COLORS[v - 1], 255);
            }
        }

        // preview of the drop + lines that would clear
        if (dragIdx >= 0 && tray[dragIdx] != null) {
            Piece p = tray[dragIdx];
            computeTarget(p);
            final int tr = tgtR, tc = tgtC;
            if (canPlace(p, tr, tc)) {
                for (int r = 0; r < N; r++)
                    for (int c = 0; c < N; c++) tmp[r][c] = grid[r][c] != 0;
                for (int[] cl : p.cells) tmp[tr + cl[0]][tc + cl[1]] = true;
                final boolean[] rf = rowFull, cf = colFull;
                for (int i = 0; i < N; i++) {
                    rf[i] = true;
                    cf[i] = true;
                    for (int j = 0; j < N; j++) {
                        if (!tmp[i][j]) rf[i] = false;
                        if (!tmp[j][i]) cf[i] = false;
                    }
                }
                int a = (int) (70 + 70 * (0.5f + 0.5f * Math.sin(now / 130.0)));
                for (int r = 0; r < N; r++)
                    for (int c = 0; c < N; c++)
                        if (rf[r] || cf[c])
                            drawFlat(canvas, gridX + c * cell, gridY + r * cell, cell, COLORS[p.color - 1], a);
                for (int[] cl : p.cells)
                    drawBlock(canvas, gridX + (tc + cl[1]) * cell, gridY + (tr + cl[0]) * cell,
                            cell, COLORS[p.color - 1], 110);
            }
        }

        // clearing cells
        Iterator<Ghost> gi = ghosts.iterator();
        while (gi.hasNext()) {
            Ghost g = gi.next();
            float t = (now - g.start) / 400f;
            if (t >= 1f) { gi.remove(); continue; }
            float s = 1f;
            int col = COLORS[g.color - 1];
            int a = 255;
            if (t >= 0f && t < 0.2f) {
                s = 1f + 0.25f * (t / 0.2f);
                col = mix(col, 0xFFFFFFFF, t / 0.2f * 0.85f);
            } else if (t >= 0.2f) {
                float k = (t - 0.2f) / 0.8f;
                s = 1.25f * (1f - k * k);
                col = mix(col, 0xFFFFFFFF, 0.85f * (1f - k));
                a = (int) (255 * (1f - 0.6f * k));
            }
            float cx = gridX + (g.c + 0.5f) * cell, cy = gridY + (g.r + 0.5f) * cell, sz = cell * s;
            drawBlock(canvas, cx - sz / 2f, cy - sz / 2f, sz, col, a);
        }

        // particles
        Iterator<Particle> pi = parts.iterator();
        while (pi.hasNext()) {
            Particle q = pi.next();
            float t = (now - q.t0) / 1000f;
            if (t < 0f) continue;
            if (t >= q.life) { pi.remove(); continue; }
            float k = t / q.life;
            float x = q.x0 + q.vx * t, y = q.y0 + q.vy * t + 0.5f * cell * 16f * t * t;
            paint.setColor(q.color);
            paint.setAlpha((int) (255 * (1f - k)));
            canvas.drawCircle(x, y, q.size * (1f - 0.6f * k), paint);
        }

        // tray
        float slotW = w / 3f;
        for (int i = 0; i < 3; i++) {
            Piece p = tray[i];
            if (p == null || i == dragIdx) continue;
            if (i == retIdx) {
                float t = clamp01((now - retStart) / 220f);
                float e = easeOutCubic(t);
                drawPieceCentered(canvas, p, lerp(retX, slotW * (i + 0.5f), e), lerp(retY, trayCy, e),
                        lerp(retSize, trayCell, e), 255);
                if (t >= 1f) retIdx = -1;
                continue;
            }
            float t = (now - slotStart[i]) / 450f;
            if (t < 0f) continue;
            float e = easeOutBack(clamp01(t));
            float yo = (1f - easeOutCubic(clamp01(t))) * cell * 2.5f;
            drawPieceCentered(canvas, p, slotW * (i + 0.5f), trayCy + yo, trayCell * e,
                    (int) (255 * clamp01(t * 3f)));
        }

        // dragged piece
        if (dragIdx >= 0 && tray[dragIdx] != null) {
            Piece p = tray[dragIdx];
            float e = easeOutCubic(clamp01((now - dragStart) / 160f));
            float sz = lerp(trayCell, cell, e);
            float cx = lerp(slotW * (dragIdx + 0.5f), dragX, e);
            float cy = lerp(trayCy, dragY, e) - cell * 1.5f * e;
            float left = cx - p.w * sz / 2f, top = cy - p.h * sz / 2f;
            for (int[] cl : p.cells)
                drawFlat(canvas, left + cl[1] * sz, top + cl[0] * sz + sz * 0.18f, sz, 0xFF000000, 60);
            drawPieceCentered(canvas, p, cx, cy, sz, 255);
        }

        // floating texts
        Iterator<FloatText> ti = texts.iterator();
        while (ti.hasNext()) {
            FloatText f = ti.next();
            float t = (now - f.start) / 1000f;
            if (t >= 1f) { ti.remove(); continue; }
            float y = f.y - cell * 1.4f * easeOutCubic(t);
            int a = (int) (255 * (t < 0.65f ? 1f : 1f - (t - 0.65f) / 0.35f));
            text.setColor(f.color);
            text.setAlpha(a);
            text.setTextSize(f.size * (0.6f + 0.4f * easeOutBack(clamp01(t * 4f))));
            canvas.drawText(f.s, f.x, y, text);
        }
        canvas.restore();

        if (gameOver && now >= gameOverStart) drawGameOver(canvas, now, w, h);
        if (isAnimating(now)) postInvalidateOnAnimation();
        else postInvalidateDelayed(IDLE_FRAME_MS); // экономим батарею, когда движется только фон
    }

    /** true, если на экране идёт анимация, которой нужна полная частота кадров. */
    private boolean isAnimating(long now) {
        return dragIdx >= 0 || retIdx >= 0 || gameOver
                || !ghosts.isEmpty() || !parts.isEmpty() || !texts.isEmpty()
                || dispScore != score
                || now - shakeStart < 380 || now - bumpStart < 260
                || now - lastPlaceTime < 320 || now < trayAnimUntil;
    }

    private void drawGameOver(Canvas canvas, long now, int w, int h) {
        float t = clamp01((now - gameOverStart) / 500f);
        canvas.drawColor((((int) (204 * t)) << 24) | 0x070A1E);
        float e = easeOutBack(t);
        float cy = h * 0.4f;
        text.setColor(0xFFFFFFFF);
        text.setTextSize(cell * 0.95f * e);
        canvas.drawText("Игра окончена", w / 2f, cy, text);
        text.setAlpha(170);
        text.setTextSize(cell * 0.5f * e);
        canvas.drawText("Счёт", w / 2f, cy + cell * 1.1f, text);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(cell * 1.6f * e);
        canvas.drawText(String.valueOf(score), w / 2f, cy + cell * 2.8f, text);
        if (newRecord) {
            text.setColor(0xFFFFD866);
            text.setTextSize(cell * 0.6f * e);
            canvas.drawText("Новый рекорд!", w / 2f, cy + cell * 3.9f, text);
        }
        float pulse = 0.6f + 0.4f * (float) Math.sin(now / 300.0);
        text.setColor(0xFFFFFFFF);
        text.setAlpha((int) (200 * pulse * t));
        text.setTextSize(cell * 0.42f);
        canvas.drawText("Нажми, чтобы играть снова", w / 2f, cy + cell * 5.4f, text);
    }
}
