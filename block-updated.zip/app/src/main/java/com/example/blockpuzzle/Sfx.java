package com.example.blockpuzzle;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/**
 * Звуковые эффекты без звуковых файлов: короткие сигналы синтезируются в коде
 * при запуске (в фоновом потоке) и проигрываются через AudioTrack.
 */
final class Sfx {
    static final int CLICK = 0, PLACE = 1, BAD = 2, CLEAR1 = 3, CLEAR2 = 4, CLEAR3 = 5, OVER = 6, UNDO = 7;
    private static final int COUNT = 8;
    private static final int RATE = 22050;

    private final AudioTrack[] tracks = new AudioTrack[COUNT];
    volatile boolean enabled = true;

    Sfx() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                build();
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void build() {
        for (int id = 0; id < COUNT; id++) {
            try {
                short[] pcm = synth(id);
                AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        pcm.length * 2, AudioTrack.MODE_STATIC);
                if (t.getState() != AudioTrack.STATE_INITIALIZED) {
                    t.release();
                    continue;
                }
                t.write(pcm, 0, pcm.length);
                t.setVolume(0.8f);
                tracks[id] = t;
            } catch (RuntimeException e) {
                // звук — приятное дополнение: если устройство не справилось, игра идёт без него
            }
        }
    }

    void play(int id) {
        if (!enabled || id < 0 || id >= COUNT) return;
        AudioTrack t = tracks[id];
        if (t == null) return;
        try {
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (RuntimeException e) {
            // игнорируем
        }
    }

    void release() {
        for (int i = 0; i < COUNT; i++) {
            AudioTrack t = tracks[i];
            tracks[i] = null;
            if (t == null) continue;
            try {
                t.release();
            } catch (RuntimeException e) {
                // игнорируем
            }
        }
    }

    // ---------- синтез ----------
    private static float[] buf(float seconds) {
        return new float[(int) (seconds * RATE)];
    }

    /** Добавляет в буфер ноту: частота плавно идёт от f0 к f1, мягкая атака и затухание. */
    private static void note(float[] b, float start, float dur, float f0, float f1, float vol, float harm) {
        int s = (int) (start * RATE), n = (int) (dur * RATE);
        double phase = 0;
        for (int i = 0; i < n && s + i < b.length; i++) {
            float t = i / (float) n;
            float f = f0 + (f1 - f0) * t;
            phase += 2 * Math.PI * f / RATE;
            float attack = Math.min(1f, i / (RATE * 0.004f));
            float env = attack * (1f - t) * (1f - t);
            b[s + i] += (float) (Math.sin(phase) + harm * Math.sin(2 * phase)) * env * vol;
        }
    }

    private static void arp(float[] b, float[] freqs, float step, float dur, float vol) {
        for (int i = 0; i < freqs.length; i++) note(b, i * step, dur, freqs[i], freqs[i], vol, 0.3f);
    }

    private static short[] synth(int id) {
        float[] b;
        switch (id) {
            case CLICK:
                b = buf(0.07f);
                note(b, 0, 0.05f, 1300, 900, 0.5f, 0f);
                break;
            case PLACE:
                b = buf(0.15f);
                note(b, 0, 0.12f, 240, 120, 0.9f, 0.35f);
                note(b, 0, 0.04f, 900, 400, 0.25f, 0f);
                break;
            case BAD:
                b = buf(0.22f);
                note(b, 0, 0.15f, 160, 100, 0.55f, 0.9f);
                note(b, 0.07f, 0.12f, 140, 90, 0.45f, 0.9f);
                break;
            case CLEAR1:
                b = buf(0.5f);
                note(b, 0, 0.1f, 240, 120, 0.6f, 0.3f);
                arp(b, new float[]{523, 659, 784}, 0.06f, 0.22f, 0.5f);
                break;
            case CLEAR2:
                b = buf(0.55f);
                note(b, 0, 0.1f, 240, 120, 0.6f, 0.3f);
                arp(b, new float[]{523, 659, 784, 1047}, 0.06f, 0.22f, 0.5f);
                break;
            case CLEAR3:
                b = buf(0.65f);
                note(b, 0, 0.1f, 240, 120, 0.6f, 0.3f);
                arp(b, new float[]{523, 659, 784, 1047, 1319, 1568}, 0.055f, 0.24f, 0.45f);
                break;
            case OVER:
                b = buf(0.95f);
                arp(b, new float[]{440, 370, 311, 262}, 0.17f, 0.35f, 0.45f);
                break;
            default: // UNDO
                b = buf(0.25f);
                note(b, 0, 0.14f, 350, 800, 0.6f, 0.2f);
                note(b, 0.1f, 0.1f, 800, 1000, 0.4f, 0f);
                break;
        }
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = b[i] * 0.7f;
            out[i] = (short) (Math.max(-1f, Math.min(1f, v)) * 32767);
        }
        return out;
    }
}
