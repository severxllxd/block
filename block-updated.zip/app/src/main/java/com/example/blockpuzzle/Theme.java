package com.example.blockpuzzle;

/** Цветовая тема игры. У каждой темы ровно 7 цветов фигур. */
final class Theme {
    final String name;
    final int bgTop, bgBottom;   // градиент фона
    final int panel, cell;       // подложка поля и пустая клетка
    final int accent;            // золотой акцент: рекорд, надписи
    final int primary;           // цвет главных кнопок
    final int[] colors;

    private Theme(String name, int bgTop, int bgBottom, int panel, int cell,
                  int accent, int primary, int... colors) {
        this.name = name;
        this.bgTop = bgTop;
        this.bgBottom = bgBottom;
        this.panel = panel;
        this.cell = cell;
        this.accent = accent;
        this.primary = primary;
        this.colors = colors;
    }

    static final Theme[] ALL = {
            new Theme("Неон", 0xFF0C1030, 0xFF2B1A55, 0xFF141838, 0xFF222851, 0xFFFFD866, 0xFF3D7BFF,
                    0xFFFF5C7A, 0xFF4DA3FF, 0xFF3DDC97, 0xFFFFC857, 0xFFB07CFF, 0xFFFF8F4D, 0xFF2FE0E0),
            new Theme("Океан", 0xFF04202E, 0xFF0B4C5F, 0xFF0A2A3A, 0xFF123B4F, 0xFFFFE08A, 0xFF0FA3B1,
                    0xFF2FE0E0, 0xFF4DA3FF, 0xFF3DDC97, 0xFFFFC857, 0xFF7C8CFF, 0xFFFF7A9C, 0xFFB8F0FF),
            new Theme("Закат", 0xFF2B0B1E, 0xFF7A2A3A, 0xFF2A1022, 0xFF401A33, 0xFFFFE9A8, 0xFFE0456B,
                    0xFFFF5C7A, 0xFFFF8F4D, 0xFFFFC857, 0xFFFF6BCB, 0xFFB07CFF, 0xFFFFD866, 0xFF4DA3FF),
            new Theme("Лес", 0xFF06190F, 0xFF14402A, 0xFF0B2418, 0xFF14392A, 0xFFFFF0A0, 0xFF2FBF71,
                    0xFF3DDC97, 0xFFB6F05C, 0xFFFFC857, 0xFF2FE0E0, 0xFF8CFF9E, 0xFFFF8F4D, 0xFFFF5C7A),
            new Theme("Ночь", 0xFF000000, 0xFF0A0A14, 0xFF0D0D18, 0xFF181826, 0xFFFFD866, 0xFF6C5CE7,
                    0xFFFF5C7A, 0xFF4DA3FF, 0xFF3DDC97, 0xFFFFC857, 0xFFB07CFF, 0xFFFF8F4D, 0xFF2FE0E0),
    };
}
