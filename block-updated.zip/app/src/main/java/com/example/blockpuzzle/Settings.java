package com.example.blockpuzzle;

import android.content.SharedPreferences;

/** Пользовательские настройки и статистика. Всё хранится в SharedPreferences. */
final class Settings {
    static final int DIFF_EASY = 0, DIFF_NORMAL = 1, DIFF_HARD = 2;
    static final String[] DIFF_NAMES = {"Лёгкая", "Обычная", "Сложная"};
    /** Сколько отмен хода даётся на одну партию на каждой сложности. */
    static final int[] UNDOS = {5, 3, 1};

    private final SharedPreferences prefs;

    boolean sound, vibration;
    int theme, difficulty;
    int games, totalLines, bestCombo;

    Settings(SharedPreferences prefs) {
        this.prefs = prefs;
        sound = prefs.getInt("set_sound", 1) != 0;
        vibration = prefs.getInt("set_vib", 1) != 0;
        theme = clamp(prefs.getInt("set_theme", 0), 0, Theme.ALL.length - 1);
        difficulty = clamp(prefs.getInt("set_diff", DIFF_NORMAL), 0, 2);
        games = Math.max(0, prefs.getInt("st_games", 0));
        totalLines = Math.max(0, prefs.getInt("st_lines", 0));
        bestCombo = Math.max(0, prefs.getInt("st_combo", 0));
    }

    void save() {
        prefs.edit()
                .putInt("set_sound", sound ? 1 : 0)
                .putInt("set_vib", vibration ? 1 : 0)
                .putInt("set_theme", theme)
                .putInt("set_diff", difficulty)
                .putInt("st_games", games)
                .putInt("st_lines", totalLines)
                .putInt("st_combo", bestCombo)
                .apply();
    }

    void resetStats() {
        games = 0;
        totalLines = 0;
        bestCombo = 0;
        save();
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
