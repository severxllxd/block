package com.example.blockpuzzle;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

import java.util.Random;

/** Звуки генерируются кодом, файлы не нужны. */
final class Sfx {
    static final int PLACE = 0, CLEAR1 = 1, CLEAR2 = 2, CLEAR3 = 3, BOMB = 4, OVER = 5, CLICK = 6, BAD = 7;
    private static final int SR = 22050;
    private final AudioTrack[] tracks = new AudioTrack[8];
    boolean enabled = true;

    Sfx() {
        try {
            tracks[PLACE] = make(notes(new float[]{392f, 523f}, 45, 14f));
            tracks[CLEAR1] = make(notes(new float[]{523f, 659f, 784f}, 70, 9f));
            tracks[CLEAR2] = make(notes(new float[]{523f, 659f, 784f, 1047f}, 70, 8f));
            tracks[CLEAR3] = make(notes(new float[]{523f, 659f, 784f, 1047f, 1319f, 1568f}, 65, 7f));
            tracks[BOMB] = make(boom());
            tracks[OVER] = make(notes(new float[]{392f, 330f, 262f, 196f}, 160, 5f));
            tracks[CLICK] = make(notes(new float[]{700f}, 40, 25f));
            tracks[BAD] = make(notes(new float[]{180f}, 90, 18f));
        } catch (Throwable ignored) {
        }
    }

    private static short[] notes(float[] freqs, int ms, float decay) {
        int per = SR * ms / 1000;
        short[] d = new short[per * freqs.length];
        for (int n = 0; n < freqs.length; n++) {
            for (int i = 0; i < per; i++) {
                double t = i / (double) SR;
                double env = Math.min(1.0, i / 110.0) * Math.exp(-decay * t);
                double s = Math.sin(2 * Math.PI * freqs[n] * t) + 0.3 * Math.sin(4 * Math.PI * freqs[n] * t);
                d[n * per + i] = (short) (s * env * 8000);
            }
        }
        return d;
    }

    private static short[] boom() {
        int n = SR * 400 / 1000;
        short[] d = new short[n];
        Random r = new Random(1);
        double y = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            y += 0.12 * ((r.nextDouble() * 2 - 1) - y);
            double env = Math.min(1.0, i / 60.0) * Math.exp(-7 * t);
            double s = y * 2.2 + Math.sin(2 * Math.PI * (90 - 60 * t) * t) * 0.8;
            d[i] = (short) (s * env * 9000);
        }
        return d;
    }

    private static AudioTrack make(short[] d) {
        AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, d.length * 2, AudioTrack.MODE_STATIC);
        t.write(d, 0, d.length);
        return t;
    }

    void play(int id) {
        if (!enabled || tracks[id] == null) return;
        try {
            AudioTrack t = tracks[id];
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (Exception ignored) {
        }
    }

    void release() {
        for (AudioTrack t : tracks) {
            try {
                if (t != null) t.release();
            } catch (Exception ignored) {
            }
        }
    }
}
