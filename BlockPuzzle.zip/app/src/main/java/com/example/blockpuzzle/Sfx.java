package com.example.blockpuzzle;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

import java.util.Random;

/**
 * Звуки синтезируются кодом (мягкая "маримба" и "глиняные" шлепки), файлы не нужны.
 * Тембры подобраны по категориям, которые используют пазл-игры: tiny pop, soft place,
 * power up, descending game over.
 */
final class Sfx {
    static final int PLACE = 0, CLEAR1 = 1, CLEAR2 = 2, CLEAR3 = 3, BOMB = 4, OVER = 5,
            CLICK = 6, BAD = 7, PICK = 8, READY = 9;
    private static final int SR = 22050;
    private final AudioTrack[] tracks = new AudioTrack[10];
    volatile boolean ready;
    boolean enabled = true;

    void init() {
        try {
            tracks[PLACE] = make(place());
            tracks[CLEAR1] = make(arp(new float[]{523.25f, 659.25f, 783.99f}, 0.07f, 0.38f, false));
            tracks[CLEAR2] = make(arp(new float[]{523.25f, 659.25f, 783.99f, 1046.5f}, 0.06f, 0.4f, false));
            tracks[CLEAR3] = make(arp(new float[]{523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f, 1568f}, 0.055f, 0.45f, true));
            tracks[BOMB] = make(bomb());
            tracks[OVER] = make(arp(new float[]{392f, 349.2f, 311.1f, 261.6f}, 0.2f, 0.7f, false));
            tracks[CLICK] = make(click());
            tracks[BAD] = make(bad());
            tracks[PICK] = make(pick());
            tracks[READY] = make(arp(new float[]{783.99f, 987.77f, 1174.66f, 1567.98f}, 0.085f, 0.55f, true));
        } catch (Throwable ignored) {
        } finally {
            ready = true;
        }
    }

    // ---------- synth ----------
    private static float[] buf(float sec) { return new float[(int) (SR * sec)]; }

    private static void tone(float[] b, float start, float f0, float f1, float dur, float amp, float decay, float harm) {
        int s0 = (int) (start * SR), n = (int) (dur * SR);
        double ph = 0;
        for (int i = 0; i < n && s0 + i < b.length; i++) {
            double t = i / (double) SR;
            double f = f1 + (f0 - f1) * Math.exp(-t * 40);
            ph += 2 * Math.PI * f / SR;
            double env = Math.min(1.0, i / (0.003 * SR)) * Math.exp(-decay * t);
            double s = Math.sin(ph) + harm * Math.sin(ph * 4.0) * Math.exp(-decay * 2 * t);
            b[s0 + i] += (float) (s * env * amp);
        }
    }

    private static void noise(float[] b, float start, float dur, float amp, float decay, float lp, long seed) {
        Random r = new Random(seed);
        int s0 = (int) (start * SR), n = (int) (dur * SR);
        double y = 0;
        for (int i = 0; i < n && s0 + i < b.length; i++) {
            double t = i / (double) SR;
            y += lp * ((r.nextDouble() * 2 - 1) - y);
            b[s0 + i] += (float) (y * Math.exp(-decay * t) * amp * 2.5);
        }
    }

    private static short[] pcm(float[] b) {
        short[] d = new short[b.length];
        for (int i = 0; i < b.length; i++) d[i] = (short) (Math.tanh(b[i]) * 30000);
        return d;
    }

    private static short[] arp(float[] freqs, float gap, float noteDur, boolean shimmer) {
        float[] b = buf(gap * freqs.length + noteDur + 0.05f);
        for (int i = 0; i < freqs.length; i++) tone(b, i * gap, freqs[i], freqs[i], noteDur, 0.42f, 9f, 0.45f);
        if (shimmer) tone(b, gap * freqs.length * 0.8f, freqs[freqs.length - 1] * 2f, freqs[freqs.length - 1] * 2f,
                0.4f, 0.12f, 7f, 0f);
        return pcm(b);
    }

    private static short[] place() {
        float[] b = buf(0.17f);
        tone(b, 0, 300, 150, 0.14f, 0.55f, 26f, 0f);
        tone(b, 0, 620, 300, 0.05f, 0.15f, 60f, 0f);
        noise(b, 0, 0.03f, 0.22f, 110f, 0.35f, 3);
        return pcm(b);
    }

    private static short[] bomb() {
        float[] b = buf(0.55f);
        tone(b, 0, 150, 42, 0.5f, 0.9f, 6f, 0f);
        noise(b, 0, 0.45f, 0.75f, 8f, 0.08f, 1);
        return pcm(b);
    }

    private static short[] click() {
        float[] b = buf(0.07f);
        tone(b, 0, 1200, 700, 0.06f, 0.45f, 55f, 0f);
        return pcm(b);
    }

    private static short[] bad() {
        float[] b = buf(0.16f);
        tone(b, 0, 200, 120, 0.14f, 0.5f, 24f, 0f);
        noise(b, 0, 0.02f, 0.15f, 120f, 0.3f, 5);
        return pcm(b);
    }

    private static short[] pick() {
        float[] b = buf(0.09f);
        tone(b, 0, 520, 820, 0.08f, 0.38f, 40f, 0.2f);
        return pcm(b);
    }

    private static AudioTrack make(short[] d) {
        AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, d.length * 2, AudioTrack.MODE_STATIC);
        t.write(d, 0, d.length);
        return t;
    }

    void play(int id) {
        if (!enabled || tracks[id] == null) return;
        try {
            AudioTrack t = tracks[id];
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (Exception ignored) {
        }
    }

    void release() {
        for (AudioTrack t : tracks) {
            try {
                if (t != null) t.release();
            } catch (Exception ignored) {
            }
        }
    }
}
