package com.example.blockpuzzle;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
    private GameView view;
    private Sfx sfx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sfx = new Sfx();
        // звуки синтезируются в фоне, пока показывается загрузочный экран
        new Thread(new Runnable() {
            @Override
            public void run() {
                sfx.init();
            }
        }).start();
        view = new GameView(this, sfx);
        setContentView(view);
    }

    @Override
    protected void onPause() {
        view.saveState();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        sfx.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        view.handleBack();
    }
}
