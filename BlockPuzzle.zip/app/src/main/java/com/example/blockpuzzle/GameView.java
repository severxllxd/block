package com.example.blockpuzzle;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameView extends View {
    private static final int N = 8;

    private static final String[][] SHAPES = {
            {"#"}, {"##"}, {"###"}, {"####"}, {"#####"},
            {"#", "#"}, {"#", "#", "#"}, {"#", "#", "#", "#"}, {"#", "#", "#", "#", "#"},
            {"##", "##"}, {"###", "###", "###"},
            {"#.", "#.", "##"}, {"..#", "..#", "###"}, {"###", "#..", "#.."}, {"###", "..#", "..#"},
            {"##", "#."}, {"##", ".#"}, {"#.", "##"}, {".#", "##"},
            {"##.", ".##"}, {".##", "##."}, {"#.", "##", ".#"}, {".#", "##", "#."},
            {"###", ".#."}, {".#.", "###"}, {"#.", "##", "#."}, {".#", "##", ".#"}
    };

    private static final int[] COLORS = {
            0xFFE74C3C, 0xFF3498DB, 0xFF2ECC71, 0xFFF1C40F,
            0xFF9B59B6, 0xFFE67E22, 0xFF1ABC9C
    };

    private static class Piece {
        int[][] cells; // {row, col}
        int w, h, color; // color: 1..COLORS.length
    }

    private final Random rnd = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final SharedPreferences prefs;

    private int[][] grid = new int[N][N];
    private final Piece[] tray = new Piece[3];
    private int score, best;
    private boolean gameOver;

    private int dragIdx = -1;
    private float dragX, dragY;
    private float cell, gridX, gridY, trayTop;

    public GameView(Context context) {
        super(context);
        prefs = context.getSharedPreferences("blockpuzzle", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(0xFFFFFFFF);
        newGame();
    }

    private void newGame() {
        grid = new int[N][N];
        score = 0;
        gameOver = false;
        dealPieces();
    }

    private void dealPieces() {
        for (int i = 0; i < 3; i++) tray[i] = randomPiece();
    }

    private Piece randomPiece() {
        String[] shape = SHAPES[rnd.nextInt(SHAPES.length)];
        List<int[]> list = new ArrayList<>();
        int w = 0;
        for (int r = 0; r < shape.length; r++) {
            w = Math.max(w, shape[r].length());
            for (int c = 0; c < shape[r].length(); c++) {
                if (shape[r].charAt(c) == '#') list.add(new int[]{r, c});
            }
        }
        Piece p = new Piece();
        p.cells = list.toArray(new int[0][]);
        p.w = w;
        p.h = shape.length;
        p.color = 1 + rnd.nextInt(COLORS.length);
        return p;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cell = Math.min(w * 0.94f / N, h * 0.5f / N);
        gridX = (w - N * cell) / 2f;
        gridY = h * 0.17f;
        trayTop = gridY + N * cell;
    }

    private boolean canPlace(Piece p, int r, int c) {
        for (int[] cl : p.cells) {
            int rr = r + cl[0], cc = c + cl[1];
            if (rr < 0 || rr >= N || cc < 0 || cc >= N || grid[rr][cc] != 0) return false;
        }
        return true;
    }

    private int[] target(Piece p) {
        float ox = dragX - p.w * cell / 2f;
        float oy = dragY - p.h * cell / 2f - cell * 1.5f;
        return new int[]{Math.round((oy - gridY) / cell), Math.round((ox - gridX) / cell)};
    }

    private void placeDragged() {
        Piece p = tray[dragIdx];
        int[] t = target(p);
        if (canPlace(p, t[0], t[1])) {
            for (int[] cl : p.cells) grid[t[0] + cl[0]][t[1] + cl[1]] = p.color;
            score += p.cells.length;
            tray[dragIdx] = null;
            clearLines();
            if (tray[0] == null && tray[1] == null && tray[2] == null) dealPieces();
            checkGameOver();
        }
    }

    private void clearLines() {
        boolean[] rows = new boolean[N];
        boolean[] cols = new boolean[N];
        int lines = 0;
        for (int i = 0; i < N; i++) {
            rows[i] = true;
            cols[i] = true;
            for (int j = 0; j < N; j++) {
                if (grid[i][j] == 0) rows[i] = false;
                if (grid[j][i] == 0) cols[i] = false;
            }
            if (rows[i]) lines++;
            if (cols[i]) lines++;
        }
        if (lines == 0) return;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (rows[i] || cols[j]) grid[i][j] = 0;
            }
        }
        score += lines * lines * 10;
    }

    private void checkGameOver() {
        for (Piece p : tray) {
            if (p == null) continue;
            for (int r = 0; r < N; r++)
                for (int c = 0; c < N; c++)
                    if (canPlace(p, r, c)) return;
        }
        gameOver = true;
        if (score > best) {
            best = score;
            prefs.edit().putInt("best", best).apply();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (gameOver) {
                    newGame();
                } else if (y > trayTop) {
                    int i = Math.max(0, Math.min(2, (int) (x / (getWidth() / 3f))));
                    if (tray[i] != null) {
                        dragIdx = i;
                        dragX = x;
                        dragY = y;
                    }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragIdx >= 0) {
                    dragX = x;
                    dragY = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragIdx >= 0) {
                    dragX = x;
                    dragY = y;
                    placeDragged();
                    dragIdx = -1;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragIdx = -1;
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }

    private void drawBlock(Canvas c, float left, float top, float size, int color) {
        float pad = size * 0.05f;
        rect.set(left + pad, top + pad, left + size - pad, top + size - pad);
        paint.setColor(color);
        c.drawRoundRect(rect, size * 0.18f, size * 0.18f, paint);
    }

    private void drawPiece(Canvas c, Piece p, float left, float top, float size, int color) {
        for (int[] cl : p.cells) drawBlock(c, left + cl[1] * size, top + cl[0] * size, size, color);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        canvas.drawColor(0xFF1B1F3B);
        paint.setStyle(Paint.Style.FILL);

        text.setTextSize(cell * 0.7f);
        canvas.drawText("Счёт: " + score, w / 2f, gridY * 0.5f, text);
        text.setTextSize(cell * 0.4f);
        canvas.drawText("Рекорд: " + Math.max(best, score), w / 2f, gridY * 0.8f, text);

        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                int v = grid[r][c];
                drawBlock(canvas, gridX + c * cell, gridY + r * cell, cell,
                        v == 0 ? 0xFF2A2F55 : COLORS[v - 1]);
            }
        }

        if (dragIdx >= 0 && tray[dragIdx] != null) {
            Piece p = tray[dragIdx];
            int[] t = target(p);
            if (canPlace(p, t[0], t[1])) {
                drawPiece(canvas, p, gridX + t[1] * cell, gridY + t[0] * cell, cell, 0x66FFFFFF);
            }
        }

        float slotW = w / 3f;
        float trayCell = Math.min(cell * 0.6f, slotW * 0.85f / 5f);
        float trayCy = trayTop + (getHeight() - trayTop) / 2f;
        for (int i = 0; i < 3; i++) {
            Piece p = tray[i];
            if (p == null || i == dragIdx) continue;
            float left = slotW * (i + 0.5f) - p.w * trayCell / 2f;
            float top = trayCy - p.h * trayCell / 2f;
            drawPiece(canvas, p, left, top, trayCell, COLORS[p.color - 1]);
        }

        if (dragIdx >= 0 && tray[dragIdx] != null) {
            Piece p = tray[dragIdx];
            drawPiece(canvas, p, dragX - p.w * cell / 2f,
                    dragY - p.h * cell / 2f - cell * 1.5f, cell, COLORS[p.color - 1]);
        }

        if (gameOver) {
            canvas.drawColor(0xBB000000);
            text.setTextSize(cell * 0.9f);
            canvas.drawText("Игра окончена", w / 2f, getHeight() * 0.42f, text);
            text.setTextSize(cell * 0.6f);
            canvas.drawText("Счёт: " + score, w / 2f, getHeight() * 0.42f + cell * 1.2f, text);
            text.setTextSize(cell * 0.45f);
            canvas.drawText("Нажми, чтобы начать заново", w / 2f, getHeight() * 0.42f + cell * 2.2f, text);
        }
    }
}
