package com.example.blockpuzzle;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Стиль: Claymorphism (мягкие "глиняные" объёмные формы, пастель, большие радиусы). */
public class GameView extends View {
    private static final int N = 8;

    private static final String[][] SHAPES = {
            {"#"}, {"##"}, {"###"}, {"####"}, {"#####"},
            {"#", "#"}, {"#", "#", "#"}, {"#", "#", "#", "#"}, {"#", "#", "#", "#", "#"},
            {"##", "##"}, {"###", "###", "###"},
            {"#.", "#.", "##"}, {"..#", "..#", "###"}, {"###", "#..", "#.."}, {"###", "..#", "..#"},
            {"##", "#."}, {"##", ".#"}, {"#.", "##"}, {".#", "##"},
            {"##.", ".##"}, {".##", "##."}, {"#.", "##", ".#"}, {".#", "##", "#."},
            {"###", ".#."}, {".#.", "###"}, {"#.", "##", "#."}, {".#", "##", ".#"}
    };

    private static final String[] TIPS = {
            "Заполняй строки и столбцы целиком",
            "После 8 линий в наборе появится бомба",
            "Серия подряд даёт больше очков",
            "Фигуры не вращаются, думай наперёд"
    };

    private static class Theme {
        final String name;
        final boolean dark;
        final int bg1, bg2, card, board, empty, text, sub, accent, onAccent;
        final int[] colors;

        Theme(String name, boolean dark, int bg1, int bg2, int card, int board, int empty,
              int text, int sub, int accent, int onAccent, int[] colors) {
            this.name = name; this.dark = dark; this.bg1 = bg1; this.bg2 = bg2;
            this.card = card; this.board = board; this.empty = empty;
            this.text = text; this.sub = sub; this.accent = accent; this.onAccent = onAccent;
            this.colors = colors;
        }
    }

    private static final Theme[] THEMES = {
            new Theme("Персик", false, 0xFFFFF1E8, 0xFFFFDFD0, 0xFFFFF8F3, 0xFFF9E0D1, 0xFFEBCBB8,
                    0xFF5A3E36, 0xFFB08D80, 0xFFFF8A65, 0xFFFFFFFF, new int[]{
                    0xFFFF8FA3, 0xFF7BB8FF, 0xFF7FDDB0, 0xFFFFD36E, 0xFFB79CFF, 0xFFFFA97A, 0xFF6FD6E0}),
            new Theme("Небо", false, 0xFFE8F3FF, 0xFFD3E6FF, 0xFFF6FAFF, 0xFFDCEAF9, 0xFFC7DAEF,
                    0xFF2D3F5C, 0xFF7C93B5, 0xFF5B8DEF, 0xFFFFFFFF, new int[]{
                    0xFFFF8FA3, 0xFF6FA8FF, 0xFF7FDDB0, 0xFFFFD36E, 0xFFB79CFF, 0xFFFFA97A, 0xFF6FD6E0}),
            new Theme("Мята", false, 0xFFE6F8F0, 0xFFCFEFE2, 0xFFF5FFFA, 0xFFD5EEE2, 0xFFBFE2D2,
                    0xFF244A3E, 0xFF75A594, 0xFF38B98A, 0xFFFFFFFF, new int[]{
                    0xFFFF8FA3, 0xFF7BB8FF, 0xFF5FD39A, 0xFFFFD36E, 0xFFB79CFF, 0xFFFFA97A, 0xFF6FD6E0}),
            new Theme("Ночь", true, 0xFF2A2640, 0xFF1D1A31, 0xFF3A3558, 0xFF322D4F, 0xFF262240,
                    0xFFF3EFFF, 0xFF9D97C4, 0xFFFFB86B, 0xFF3A2200, new int[]{
                    0xFFFF8FB1, 0xFF7DB4FF, 0xFF6BE3B5, 0xFFFFD87A, 0xFFBBA3FF, 0xFFFFA97A, 0xFF73DCE8})
    };

    private static class Piece { int[][] cells; int w, h, color, idx; boolean bomb; }
    private static class Ghost { int r, c, color; long start; }
    private static class Particle { float x0, y0, vx, vy, size, life, rot; long t0; int color; }
    private static class FloatText { String s; float x, y, size; long start; int color; boolean pill; }

    private final Random rnd = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmpR = new RectF();
    private final RectF cellR = new RectF();
    private final RectF scoreR = new RectF(), bestR = new RectF(), pauseR = new RectF(), dockR = new RectF();
    private final RectF[] menuR = new RectF[6];
    private final RectF menuCard = new RectF();
    private float menuStatsY;
    private final Path crown = new Path();
    private final Typeface fontBlack, fontXB;
    private final RadialGradient bombSh;
    private final SharedPreferences prefs;
    private final Sfx sfx;

    private Bitmap bgBmp;
    private RadialGradient[] tileSh;

    private int[][] grid = new int[N][N];
    private final long[][] popStart = new long[N][N];
    private final boolean[][] tmp = new boolean[N][N];
    private final Piece[] tray = new Piece[3];
    private final long[] slotStart = new long[3];
    private final List<Ghost> ghosts = new ArrayList<>();
    private final List<Particle> parts = new ArrayList<>();
    private final List<FloatText> texts = new ArrayList<>();

    private Theme theme;
    private int[] colors;
    private int themeIdx;
    private boolean soundOn, vibeOn, menuOpen;
    private int score, best, combo;
    private int games, totalLines, bestCombo, linesSinceBomb;
    private boolean bombReady, overSound;
    private float dispScore;
    private long bumpStart, lastFrame, shakeStart, gameOverStart, menuStart, frameNow;
    private float shakeAmp;
    private boolean gameOver, newRecord;

    private boolean loading = true;
    private long loadStart, loadEnd;

    private int dragIdx = -1, retIdx = -1;
    private float dragX, dragY, retX, retY, retSize;
    private long dragStart, retStart;
    private float cell, boardW, gridX, gridY, trayTop, trayCy, hudTop, hudH;

    public GameView(Context context, Sfx sfx) {
        super(context);
        this.sfx = sfx;
        setKeepScreenOn(true);
        fontBlack = loadFont(context, "fonts/Nunito-Black.ttf");
        fontXB = loadFont(context, "fonts/Nunito-ExtraBold.ttf");
        bombSh = new RadialGradient(0.4f, 0.42f, 0.5f,
                new int[]{0xFF6B7194, 0xFF2E3140, 0xFF1B1D28}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        for (int i = 0; i < menuR.length; i++) menuR[i] = new RectF();
        crown.moveTo(0f, 0.9f);
        crown.lineTo(0f, 0.2f);
        crown.lineTo(0.25f, 0.55f);
        crown.lineTo(0.5f, 0.05f);
        crown.lineTo(0.75f, 0.55f);
        crown.lineTo(1f, 0.2f);
        crown.lineTo(1f, 0.9f);
        crown.close();
        prefs = context.getSharedPreferences("blockpuzzle", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        games = prefs.getInt("games", 0);
        totalLines = prefs.getInt("lines", 0);
        bestCombo = prefs.getInt("bestCombo", 0);
        soundOn = prefs.getBoolean("sound", true);
        vibeOn = prefs.getBoolean("vibe", true);
        themeIdx = Math.max(0, Math.min(THEMES.length - 1, prefs.getInt("theme", 0)));
        sfx.enabled = soundOn;
        setTheme(themeIdx, false);
        long now = SystemClock.uptimeMillis();
        if (!restoreState(now)) newGame(now);
    }

    private static Typeface loadFont(Context c, String path) {
        try {
            return Typeface.createFromAsset(c.getAssets(), path);
        } catch (Exception e) {
            return Typeface.create("sans-serif", Typeface.BOLD);
        }
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float easeOutCubic(float t) { float u = 1 - t; return 1 - u * u * u; }
    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1, u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }
    private static int mix(int a, int b, float t) {
        int r = (int) lerp((a >> 16) & 255, (b >> 16) & 255, t);
        int g = (int) lerp((a >> 8) & 255, (b >> 8) & 255, t);
        int bl = (int) lerp(a & 255, b & 255, t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private void haptic(int kind) { if (vibeOn) performHapticFeedback(kind); }

    private void drawT(Canvas c, String s, float x, float y, float size, int color, int alpha,
                       Paint.Align al, Typeface tf, float spacing) {
        text.setTypeface(tf);
        text.setTextAlign(al);
        text.setTextSize(size);
        text.setLetterSpacing(spacing);
        text.setColor(color);
        text.setAlpha(alpha);
        c.drawText(s, x, y, text);
    }

    private void setTheme(int idx, boolean save) {
        themeIdx = idx;
        theme = THEMES[idx];
        colors = theme.colors;
        tileSh = new RadialGradient[colors.length];
        for (int i = 0; i < colors.length; i++) {
            tileSh[i] = new RadialGradient(0.36f, 0.30f, 0.95f,
                    new int[]{mix(colors[i], 0xFFFFFFFF, 0.45f), colors[i], mix(colors[i], 0xFF000000, 0.18f)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        }
        if (save) prefs.edit().putInt("theme", idx).apply();
        buildBg();
    }

    /** Фон: мягкий градиент и разбросанные "глиняные" игрушки. */
    private void buildBg() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || cell <= 0) return;
        if (bgBmp != null) bgBmp.recycle();
        bgBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bgBmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, h, theme.bg1, theme.bg2, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        Random r = new Random(7);
        for (int k = 0; k < 16; k++) {
            float cx = r.nextFloat() * w, cy = r.nextFloat() * h;
            float s = cell * (0.5f + r.nextFloat() * 0.9f);
            int col = colors[k % colors.length];
            c.save();
            c.translate(cx, cy);
            c.rotate(r.nextFloat() * 60f - 30f);
            c.scale(s, s);
            p.setShader(new RadialGradient(-0.15f, -0.2f, 0.9f,
                    new int[]{mix(col, 0xFFFFFFFF, 0.4f), col, mix(col, 0xFF000000, 0.12f)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            p.setAlpha(theme.dark ? 70 : 95);
            if (k % 3 == 0) c.drawCircle(0f, 0f, 0.5f, p);
            else {
                RectF rr = new RectF(-0.5f, -0.5f, 0.5f, 0.5f);
                c.drawRoundRect(rr, 0.32f, 0.32f, p);
            }
            c.restore();
        }
    }

    // ---------- save / restore ----------
    public void saveState() {
        SharedPreferences.Editor ed = prefs.edit();
        ed.putInt("best", best).putInt("games", games).putInt("lines", totalLines).putInt("bestCombo", bestCombo);
        if (gameOver) {
            ed.remove("state");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(score).append(';').append(combo).append(';').append(linesSinceBomb).append(';');
            for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) sb.append(grid[r][c]);
            sb.append(';');
            for (int i = 0; i < 3; i++) {
                Piece p = tray[i];
                if (p == null) sb.append('-');
                else if (p.bomb) sb.append('b');
                else sb.append(p.idx).append(':').append(p.color);
                if (i < 2) sb.append(',');
            }
            ed.putString("state", sb.toString());
        }
        ed.apply();
    }

    private boolean restoreState(long now) {
        String s = prefs.getString("state", null);
        if (s == null) return false;
        try {
            String[] a = s.split(";", -1);
            if (a.length < 5 || a[3].length() != N * N) return false;
            int sc = Integer.parseInt(a[0]), cb = Integer.parseInt(a[1]), lb = Integer.parseInt(a[2]);
            int[][] g = new int[N][N];
            for (int i = 0; i < N * N; i++) {
                int v = a[3].charAt(i) - '0';
                if (v < 0 || v > colors.length) return false;
                g[i / N][i % N] = v;
            }
            String[] tp = a[4].split(",", -1);
            if (tp.length != 3) return false;
            Piece[] np = new Piece[3];
            boolean any = false;
            for (int i = 0; i < 3; i++) {
                String q = tp[i];
                if (q.equals("-")) continue;
                if (q.equals("b")) {
                    np[i] = bombPiece();
                } else {
                    String[] pc = q.split(":");
                    int idx = Integer.parseInt(pc[0]), col = Integer.parseInt(pc[1]);
                    if (idx < 0 || idx >= SHAPES.length || col < 1 || col > colors.length) return false;
                    np[i] = makePiece(idx, col);
                }
                any = true;
            }
            if (!any) return false;
            grid = g;
            score = sc; dispScore = sc; combo = cb; linesSinceBomb = lb;
            bombReady = lb >= 8;
            for (int i = 0; i < 3; i++) {
                tray[i] = np[i];
                slotStart[i] = now + 150 + i * 110L;
            }
            for (long[] row : popStart) Arrays.fill(row, 0);
            gameOver = false;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- game logic ----------
    private void newGame(long now) {
        grid = new int[N][N];
        for (long[] row : popStart) Arrays.fill(row, 0);
        ghosts.clear();
        parts.clear();
        texts.clear();
        score = 0;
        dispScore = 0;
        combo = 0;
        linesSinceBomb = 0;
        bombReady = false;
        gameOver = false;
        newRecord = false;
        overSound = false;
        dragIdx = -1;
        retIdx = -1;
        dealPieces(now);
    }

    private void dealPieces(long now) {
        for (int attempt = 0; attempt < 30; attempt++) {
            for (int i = 0; i < 3; i++) tray[i] = randomPiece();
            if (anyFits()) break;
        }
        if (bombReady) {
            tray[1] = bombPiece();
            bombReady = false;
            linesSinceBomb = 0;
            addPill("Бомба в наборе", getWidth() / 2f, trayTop - cell * 0.1f, cell * 0.3f, 0xFFFF7A3D, now + 400);
        }
        for (int i = 0; i < 3; i++) slotStart[i] = now + 120 + i * 110L;
    }

    private Piece makePiece(int idx, int color) {
        String[] shape = SHAPES[idx];
        List<int[]> list = new ArrayList<>();
        int w = 0;
        for (int r = 0; r < shape.length; r++) {
            w = Math.max(w, shape[r].length());
            for (int c = 0; c < shape[r].length(); c++) {
                if (shape[r].charAt(c) == '#') list.add(new int[]{r, c});
            }
        }
        Piece p = new Piece();
        p.cells = list.toArray(new int[0][]);
        p.w = w;
        p.h = shape.length;
        p.color = color;
        p.idx = idx;
        return p;
    }

    private Piece randomPiece() {
        return makePiece(rnd.nextInt(SHAPES.length), 1 + rnd.nextInt(colors.length));
    }

    private Piece bombPiece() {
        Piece p = new Piece();
        p.cells = new int[][]{{0, 0}};
        p.w = 1;
        p.h = 1;
        p.color = 1;
        p.idx = -1;
        p.bomb = true;
        return p;
    }

    private boolean canPlace(Piece p, int r, int c) {
        for (int[] cl : p.cells) {
            int rr = r + cl[0], cc = c + cl[1];
            if (rr < 0 || rr >= N || cc < 0 || cc >= N) return false;
            if (!p.bomb && grid[rr][cc] != 0) return false;
        }
        return true;
    }

    private boolean anyFits() {
        for (Piece p : tray) {
            if (p == null) continue;
            for (int r = 0; r < N; r++)
                for (int c = 0; c < N; c++)
                    if (canPlace(p, r, c)) return true;
        }
        return false;
    }

    private boolean boardEmpty() {
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) if (grid[r][c] != 0) return false;
        return true;
    }

    private float slotCx(int i) { return gridX + boardW * (i + 0.5f) / 3f; }

    private float traySize(Piece p) {
        return Math.min(cell * 0.72f, (boardW / 3f) * 0.84f / Math.max(p.w, p.h));
    }

    private int[] target(Piece p) {
        float ox = dragX - p.w * cell / 2f;
        float oy = dragY - cell * 1.5f - p.h * cell / 2f;
        return new int[]{Math.round((oy - gridY) / cell), Math.round((ox - gridX) / cell)};
    }

    private void addText(String s, float x, float y, float size, int color, long now) {
        FloatText f = new FloatText();
        f.s = s; f.x = x; f.y = y; f.size = size; f.color = color; f.start = now;
        texts.add(f);
    }

    private void addPill(String s, float x, float y, float size, int color, long now) {
        FloatText f = new FloatText();
        f.s = s; f.x = x; f.y = y; f.size = size; f.color = color; f.start = now; f.pill = true;
        texts.add(f);
    }

    private void addGhost(int i, int j, long start) {
        int v = grid[i][j];
        if (v == 0) return;
        Ghost g = new Ghost();
        g.r = i; g.c = j; g.color = v; g.start = start;
        ghosts.add(g);
        float cx = gridX + (j + 0.5f) * cell, cy = gridY + (i + 0.5f) * cell;
        for (int k = 0; k < 5; k++) {
            Particle q = new Particle();
            float ang = rnd.nextFloat() * 6.2832f;
            float sp = cell * (1.5f + rnd.nextFloat() * 4f);
            q.x0 = cx; q.y0 = cy;
            q.vx = (float) Math.cos(ang) * sp;
            q.vy = (float) Math.sin(ang) * sp - cell * 2f;
            q.size = cell * (0.08f + rnd.nextFloat() * 0.1f);
            q.t0 = start;
            q.life = 0.6f + rnd.nextFloat() * 0.5f;
            q.rot = (rnd.nextFloat() - 0.5f) * 900f;
            q.color = colors[v - 1];
            parts.add(q);
        }
        grid[i][j] = 0;
    }

    private int explode(int r0, int c0, long now) {
        float bx = gridX + (c0 + 0.5f) * cell, by = gridY + (r0 + 0.5f) * cell;
        for (int k = 0; k < 26; k++) {
            Particle q = new Particle();
            float ang = rnd.nextFloat() * 6.2832f;
            float sp = cell * (3f + rnd.nextFloat() * 6f);
            q.x0 = bx; q.y0 = by;
            q.vx = (float) Math.cos(ang) * sp;
            q.vy = (float) Math.sin(ang) * sp;
            q.size = cell * (0.08f + rnd.nextFloat() * 0.12f);
            q.t0 = now;
            q.life = 0.5f + rnd.nextFloat() * 0.6f;
            q.rot = (rnd.nextFloat() - 0.5f) * 1000f;
            q.color = (k % 2 == 0) ? 0xFFFFC857 : 0xFFFF7A3D;
            parts.add(q);
        }
        int n = 0;
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                int rr = r0 + dr, cc = c0 + dc;
                if (rr < 0 || rr >= N || cc < 0 || cc >= N || grid[rr][cc] == 0) continue;
                addGhost(rr, cc, now + Math.max(Math.abs(dr), Math.abs(dc)) * 40L);
                n++;
            }
        }
        return n;
    }

    private int clearLines(long now) {
        boolean[] rows = new boolean[N];
        boolean[] cols = new boolean[N];
        int lines = 0;
        for (int i = 0; i < N; i++) {
            rows[i] = true;
            cols[i] = true;
            for (int j = 0; j < N; j++) {
                if (grid[i][j] == 0) rows[i] = false;
                if (grid[j][i] == 0) cols[i] = false;
            }
            if (rows[i]) lines++;
            if (cols[i]) lines++;
        }
        if (lines == 0) return 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (!(rows[i] || cols[j])) continue;
                float d = Math.min(rows[i] ? j : 99, cols[j] ? i : 99) * 24f;
                addGhost(i, j, now + (long) d);
            }
        }
        return lines;
    }

    private void placeDragged(long now) {
        Piece p = tray[dragIdx];
        int[] t = target(p);
        if (!canPlace(p, t[0], t[1])) {
            float e = easeOutCubic(clamp01((now - dragStart) / 160f));
            retX = lerp(slotCx(dragIdx), dragX, e);
            retY = lerp(trayCy, dragY, e) - cell * 1.5f * e;
            retSize = lerp(traySize(p), cell, e);
            retStart = now;
            retIdx = dragIdx;
            if (dragY < trayTop) sfx.play(Sfx.BAD);
            return;
        }
        tray[dragIdx] = null;
        float cxm = getWidth() / 2f, cym = gridY + boardW * 0.42f;
        int gained;
        if (p.bomb) {
            int n = explode(t[0], t[1], now);
            gained = 5 + n * 3;
            addPill("Бум!", cxm, cym, cell * 0.42f, 0xFFFF7A3D, now);
            shakeStart = now;
            shakeAmp = cell * 0.25f;
            sfx.play(Sfx.BOMB);
            haptic(HapticFeedbackConstants.LONG_PRESS);
        } else {
            for (int[] cl : p.cells) {
                grid[t[0] + cl[0]][t[1] + cl[1]] = p.color;
                popStart[t[0] + cl[0]][t[1] + cl[1]] = now;
            }
            gained = p.cells.length;
            int lines = clearLines(now);
            if (lines > 0) {
                combo++;
                bestCombo = Math.max(bestCombo, combo);
                totalLines += lines;
                linesSinceBomb += lines;
                bombReady = linesSinceBomb >= 8;
                gained += lines * lines * 10 + (combo - 1) * 5;
                String label = lines >= 3 ? "Потрясающе!" : lines == 2 ? "Отлично!" : combo >= 2 ? "Серия ×" + combo : null;
                if (label != null) addPill(label, cxm, cym, cell * 0.42f, theme.accent, now);
                if (lines >= 2) {
                    shakeStart = now;
                    shakeAmp = cell * 0.09f * Math.min(lines, 4);
                }
                sfx.play((lines >= 3 || combo >= 3) ? Sfx.CLEAR3 : (lines == 2 || combo == 2) ? Sfx.CLEAR2 : Sfx.CLEAR1);
                haptic(HapticFeedbackConstants.LONG_PRESS);
            } else {
                combo = 0;
                sfx.play(Sfx.PLACE);
                haptic(HapticFeedbackConstants.KEYBOARD_TAP);
            }
        }
        if (boardEmpty()) {
            gained += 100;
            addPill("Идеально! +100", cxm, cym - cell * 1.1f, cell * 0.38f, 0xFF38B98A, now);
            sfx.play(Sfx.CLEAR3);
        }
        score += gained;
        bumpStart = now;
        addText("+" + gained, gridX + (t[1] + p.w / 2f) * cell, gridY + (t[0] + p.h / 2f) * cell,
                cell * 0.55f, 0xFFFFFFFF, now);
        if (tray[0] == null && tray[1] == null && tray[2] == null) dealPieces(now);
        checkGameOver(now);
    }

    private void checkGameOver(long now) {
        if (anyFits()) return;
        gameOver = true;
        gameOverStart = now + 700;
        games++;
        newRecord = score > best && score > 0;
        if (newRecord) best = score;
        saveState();
    }

    // ---------- menu ----------
    public boolean handleBack() {
        if (loading) return true;
        menuOpen = !menuOpen;
        menuStart = SystemClock.uptimeMillis();
        dragIdx = -1;
        return true;
    }

    private void layoutMenu() {
        float w = getWidth(), h = getHeight();
        float cw = Math.min(w * 0.88f, cell * 7.8f), p = cell * 0.5f, g = cell * 0.2f;
        float x = (w - cw) / 2f, bw = cw - 2 * p;
        float totalH = p + cell * 1.1f + cell * 1.0f + g + cell * 0.9f + cell * 0.3f + cell * 1.5f
                + cell * 0.35f + cell * 1.1f + cell * 0.2f + cell * 0.8f + p;
        float y = (h - totalH) / 2f;
        menuCard.set(x, y, x + cw, y + totalH);
        float cy = y + p + cell * 1.1f;
        menuR[0].set(x + p, cy, x + p + bw, cy + cell * 1.0f);
        cy += cell * 1.0f + g;
        menuR[1].set(x + p, cy, x + p + bw, cy + cell * 0.9f);
        cy += cell * 0.9f + cell * 0.3f;
        float tw = (bw - 2 * g) / 3f;
        for (int k = 0; k < 3; k++)
            menuR[2 + k].set(x + p + k * (tw + g), cy, x + p + k * (tw + g) + tw, cy + cell * 1.5f);
        cy += cell * 1.5f + cell * 0.35f;
        menuStatsY = cy;
        cy += cell * 1.1f + cell * 0.2f;
        menuR[5].set(x + p, cy, x + p + bw, cy + cell * 0.8f);
    }

    private void menuAction(int i, long now) {
        switch (i) {
            case 0: menuOpen = false; break;
            case 1: newGame(now); menuOpen = false; break;
            case 2:
                soundOn = !soundOn;
                sfx.enabled = soundOn;
                prefs.edit().putBoolean("sound", soundOn).apply();
                break;
            case 3:
                vibeOn = !vibeOn;
                prefs.edit().putBoolean("vibe", vibeOn).apply();
                break;
            case 4:
                setTheme((themeIdx + 1) % THEMES.length, true);
                break;
            case 5:
                saveState();
                ((Activity) getContext()).finish();
                break;
        }
        sfx.play(Sfx.CLICK);
    }

    // ---------- input ----------
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cell = Math.min(w * 0.94f / N, h * 0.067f);
        boardW = N * cell;
        gridX = (w - boardW) / 2f;
        hudH = cell * 1.45f;
        float total = hudH + cell * 0.6f + boardW + cell * 0.5f + cell * 3.2f;
        hudTop = Math.max(h * 0.05f, (h - total) * 0.4f);
        gridY = hudTop + hudH + cell * 0.6f;
        trayTop = gridY + boardW;
        float dockTop = trayTop + cell * 0.5f;
        dockR.set(gridX, dockTop, gridX + boardW, dockTop + cell * 3.2f);
        trayCy = dockR.centerY();
        float gap = cell * 0.18f, btnW = hudH * 0.78f, rest = boardW - btnW - 2 * gap;
        scoreR.set(gridX, hudTop, gridX + rest * 0.6f, hudTop + hudH);
        bestR.set(scoreR.right + gap, hudTop, scoreR.right + gap + rest * 0.4f, hudTop + hudH);
        pauseR.set(gridX + boardW - btnW, hudTop, gridX + boardW, hudTop + hudH);
        buildBg();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (loading) return true;
        long now = SystemClock.uptimeMillis();
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (menuOpen) {
                    layoutMenu();
                    for (int i = 0; i < 6; i++) {
                        if (menuR[i].contains(x, y)) { menuAction(i, now); break; }
                    }
                    return true;
                }
                if (pauseR.contains(x, y)) {
                    menuOpen = true;
                    menuStart = now;
                    dragIdx = -1;
                    sfx.play(Sfx.CLICK);
                    return true;
                }
                if (gameOver) {
                    if (now > gameOverStart + 500) newGame(now);
                    return true;
                }
                if (y > trayTop) {
                    int i = Math.max(0, Math.min(2, (int) ((x - gridX) / (boardW / 3f))));
                    if (tray[i] != null && now >= slotStart[i]) {
                        dragIdx = i;
                        dragX = x;
                        dragY = y;
                        dragStart = now;
                        if (retIdx == i) retIdx = -1;
                        sfx.play(Sfx.PICK);
                    }
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragIdx >= 0) { dragX = x; dragY = y; }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragIdx >= 0) {
                    dragX = x;
                    dragY = y;
                    placeDragged(now);
                    dragIdx = -1;
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragIdx = -1;
                return true;
        }
        return super.onTouchEvent(e);
    }

    // ---------- clay primitives ----------
    /** Выпуклая "глиняная" карточка: цветная тень, градиент и блик. */
    private void drawClay(Canvas c, RectF r, float radius, int color, int alpha) {
        float off = cell * 0.1f;
        paint.setShader(null);
        paint.setColor(mix(color, 0xFF000000, theme.dark ? 0.6f : 0.3f));
        paint.setAlpha((int) ((theme.dark ? 130 : 80) * alpha / 255f));
        rect.set(r.left + cell * 0.02f, r.top + off, r.right - cell * 0.02f, r.bottom + off);
        c.drawRoundRect(rect, radius, radius, paint);
        paint.setAlpha((int) ((theme.dark ? 60 : 40) * alpha / 255f));
        rect.set(r.left - cell * 0.03f, r.top + off * 0.6f, r.right + cell * 0.03f, r.bottom + off * 1.5f);
        c.drawRoundRect(rect, radius + cell * 0.03f, radius + cell * 0.03f, paint);
        paint.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                mix(color, 0xFFFFFFFF, 0.28f), mix(color, 0xFF000000, 0.07f), Shader.TileMode.CLAMP));
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha(alpha);
        c.drawRoundRect(r, radius, radius, paint);
        paint.setShader(null);
        float hh = Math.min(r.height() * 0.2f, cell * 0.16f);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha((int) ((theme.dark ? 40 : 90) * alpha / 255f));
        rect.set(r.left + r.width() * 0.07f, r.top + r.height() * 0.1f, r.left + r.width() * 0.5f, r.top + r.height() * 0.1f + hh);
        c.drawRoundRect(rect, hh / 2f, hh / 2f, paint);
    }

    /** Вдавленная "ямка" (пустая клетка, дорожка прогресса). */
    private void drawDimple(Canvas c, RectF r, float radius) {
        float dy = cell * 0.03f;
        paint.setShader(null);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha(theme.dark ? 22 : 120);
        rect.set(r.left, r.top + dy, r.right, r.bottom + dy);
        c.drawRoundRect(rect, radius, radius, paint);
        paint.setColor(mix(theme.empty, 0xFF000000, theme.dark ? 0.4f : 0.14f));
        paint.setAlpha(255);
        c.drawRoundRect(r, radius, radius, paint);
        paint.setColor(theme.empty);
        paint.setAlpha(255);
        rect.set(r.left + cell * 0.02f, r.top + cell * 0.04f, r.right - cell * 0.02f, r.bottom - cell * 0.005f);
        c.drawRoundRect(rect, radius * 0.92f, radius * 0.92f, paint);
    }

    private void drawFlat(Canvas c, float left, float top, float size, int color, int alpha) {
        paint.setShader(null);
        paint.setColor(color);
        paint.setAlpha(alpha);
        rect.set(left + size * 0.06f, top + size * 0.06f, left + size * 0.94f, top + size * 0.94f);
        c.drawRoundRect(rect, size * 0.3f, size * 0.3f, paint);
    }

    /** Пухлая плитка из глины: радиальный градиент, блик, мягкая тень. */
    private void drawTile(Canvas c, float left, float top, float size, int idx, int alpha, boolean shadow) {
        c.save();
        c.translate(left, top);
        c.scale(size, size);
        paint.setShader(null);
        if (shadow) {
            paint.setColor(mix(colors[idx], 0xFF000000, 0.45f));
            paint.setAlpha((int) (alpha * 0.22f));
            rect.set(0.10f, 0.16f, 0.90f, 1.02f);
            c.drawRoundRect(rect, 0.34f, 0.34f, paint);
            paint.setAlpha((int) (alpha * 0.16f));
            rect.set(0.05f, 0.12f, 0.95f, 1.08f);
            c.drawRoundRect(rect, 0.38f, 0.38f, paint);
        }
        paint.setShader(tileSh[idx]);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha(alpha);
        rect.set(0.05f, 0.05f, 0.95f, 0.95f);
        c.drawRoundRect(rect, 0.34f, 0.34f, paint);
        paint.setShader(null);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha((int) (alpha * 0.42f));
        rect.set(0.17f, 0.12f, 0.50f, 0.26f);
        c.drawRoundRect(rect, 0.07f, 0.07f, paint);
        paint.setAlpha((int) (alpha * 0.25f));
        c.drawCircle(0.60f, 0.19f, 0.035f, paint);
        c.restore();
    }

    private void drawTile(Canvas c, float left, float top, float size, int idx, int alpha) {
        drawTile(c, left, top, size, idx, alpha, false);
    }

    private void drawBomb(Canvas c, float cx, float cy, float size, int alpha) {
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(size, size);
        paint.setShader(bombSh);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha(alpha);
        c.drawCircle(0.5f, 0.58f, 0.36f, paint);
        paint.setShader(null);
        paint.setColor(0xFFFFFFFF);
        paint.setAlpha((int) (alpha * 0.35f));
        rect.set(0.28f, 0.36f, 0.46f, 0.46f);
        c.drawRoundRect(rect, 0.05f, 0.05f, paint);
        paint.setColor(0xFFD9CDBF);
        paint.setAlpha(alpha);
        rect.set(0.54f, 0.14f, 0.62f, 0.27f);
        c.drawRoundRect(rect, 0.03f, 0.03f, paint);
        float pulse = 0.5f + 0.5f * (float) Math.sin(frameNow / 90.0);
        paint.setColor(0xFFFFB347);
        paint.setAlpha((int) (alpha * (0.6f + 0.4f * pulse)));
        c.drawCircle(0.58f, 0.11f, 0.07f + 0.03f * pulse, paint);
        c.restore();
    }

    private void drawPieceCentered(Canvas c, Piece p, float cx, float cy, float size, int alpha, boolean shadow) {
        if (p.bomb) { drawBomb(c, cx, cy, size, alpha); return; }
        float left = cx - p.w * size / 2f, top = cy - p.h * size / 2f;
        for (int[] cl : p.cells)
            drawTile(c, left + cl[1] * size, top + cl[0] * size, size, p.color - 1, alpha, shadow);
    }

    private void drawPill(Canvas c, String s, float cx, float cy, float size, int fill, int fg, int alpha, float scale) {
        text.setTypeface(fontXB);
        text.setTextSize(size);
        text.setLetterSpacing(0.04f);
        float tw = text.measureText(s);
        float ph = size * 1.9f, pw = tw + size * 1.6f;
        c.save();
        c.scale(scale, scale, cx, cy);
        RectF pr = new RectF(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f);
        drawClay(c, pr, ph / 2f, fill, alpha);
        drawT(c, s, cx, cy + size * 0.35f, size, fg, alpha, Paint.Align.CENTER, fontXB, 0.04f);
        c.restore();
    }

    // ---------- main draw ----------
    @Override
    protected void onDraw(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        frameNow = now;
        if (loadStart == 0) loadStart = now;
        if (loading && loadEnd == 0 && now - loadStart >= 2000 && sfx.ready) {
            loadEnd = now;
            sfx.play(Sfx.READY);
            for (int i = 0; i < 3; i++) slotStart[i] = loadEnd + 250 + i * 110L;
        }
        if (loading && loadEnd != 0 && now - loadEnd > 450) loading = false;

        float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        dispScore += (score - dispScore) * Math.min(1f, dt * 9f);
        if (Math.abs(score - dispScore) < 0.6f) dispScore = score;
        int w = getWidth(), h = getHeight();
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);

        if (bgBmp != null) canvas.drawBitmap(bgBmp, 0, 0, null);
        else canvas.drawColor(theme.bg1);

        canvas.save();
        if (now - shakeStart < 380) {
            float t = (now - shakeStart) / 380f;
            canvas.translate(shakeAmp * (float) Math.sin(t * 50) * (1 - t),
                    shakeAmp * (float) Math.cos(t * 43) * (1 - t));
        }

        drawHud(canvas, now);

        if (combo >= 2 && !gameOver) {
            float yc = hudTop + hudH + (gridY - hudTop - hudH) / 2f;
            float sc = 1f + 0.05f * (float) Math.sin(now / 200.0);
            drawPill(canvas, "СЕРИЯ ×" + combo, w / 2f, yc, cell * 0.22f, theme.accent, theme.onAccent, 255, sc);
        }

        // board
        RectF boardR = new RectF(gridX - cell * 0.14f, gridY - cell * 0.14f,
                gridX + boardW + cell * 0.14f, gridY + boardW + cell * 0.14f);
        drawClay(canvas, boardR, cell * 0.42f, theme.board, 255);
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                float left = gridX + c * cell, top = gridY + r * cell;
                cellR.set(left + cell * 0.06f, top + cell * 0.06f, left + cell * 0.94f, top + cell * 0.94f);
                drawDimple(canvas, cellR, cell * 0.3f);
                int v = grid[r][c];
                if (v == 0) continue;
                float s = 1f;
                long ps = popStart[r][c];
                if (ps > 0) {
                    float t = clamp01((now - ps) / 300f);
                    if (t < 1f) s = 0.5f + 0.5f * easeOutBack(t);
                }
                float sz = cell * s;
                drawTile(canvas, left + (cell - sz) / 2f, top + (cell - sz) / 2f, sz, v - 1, 255);
            }
        }

        drawPreview(canvas, now);

        // clearing tiles
        Iterator<Ghost> gi = ghosts.iterator();
        while (gi.hasNext()) {
            Ghost g = gi.next();
            float t = (now - g.start) / 420f;
            if (t >= 1f) { gi.remove(); continue; }
            float s = 1f, rot = 0f, flash = 0f;
            int a = 255;
            if (t >= 0f && t < 0.18f) {
                s = 1f + 0.12f * (t / 0.18f);
                flash = 150f * (t / 0.18f);
            } else if (t >= 0.18f) {
                float k = (t - 0.18f) / 0.82f;
                s = 1.12f * (1f - k * k);
                rot = k * 25f * (((g.r + g.c) % 2 == 0) ? 1f : -1f);
                flash = 150f * (1f - k);
                a = (int) (255 * (1f - 0.5f * k));
            }
            float cx = gridX + (g.c + 0.5f) * cell, cy = gridY + (g.r + 0.5f) * cell, sz = cell * s;
            canvas.save();
            canvas.rotate(rot, cx, cy);
            drawTile(canvas, cx - sz / 2f, cy - sz / 2f, sz, g.color - 1, a);
            if (flash > 0f) drawFlat(canvas, cx - sz / 2f, cy - sz / 2f, sz, 0xFFFFFFFF, (int) flash);
            canvas.restore();
        }

        // confetti
        Iterator<Particle> pi = parts.iterator();
        while (pi.hasNext()) {
            Particle q = pi.next();
            float t = (now - q.t0) / 1000f;
            if (t < 0f) continue;
            if (t >= q.life) { pi.remove(); continue; }
            float k = t / q.life;
            float x = q.x0 + q.vx * t, y = q.y0 + q.vy * t + 0.5f * cell * 16f * t * t;
            float pw = q.size * 1.6f * (1f - 0.5f * k), ph = q.size * 0.9f * (1f - 0.5f * k);
            paint.setShader(null);
            paint.setColor(q.color);
            paint.setAlpha((int) (255 * (1f - k * k)));
            canvas.save();
            canvas.translate(x, y);
            canvas.rotate(q.rot * t);
            rect.set(-pw / 2f, -ph / 2f, pw / 2f, ph / 2f);
            canvas.drawRoundRect(rect, ph * 0.4f, ph * 0.4f, paint);
            canvas.restore();
        }

        drawTray(canvas, now);

        // floating texts
        Iterator<FloatText> ti = texts.iterator();
        while (ti.hasNext()) {
            FloatText f = ti.next();
            float t = (now - f.start) / 1000f;
            if (t >= 1f) { ti.remove(); continue; }
            if (t < 0f) continue;
            int a = (int) (255 * (t < 0.65f ? 1f : 1f - (t - 0.65f) / 0.35f));
            float sc = 0.6f + 0.4f * easeOutBack(clamp01(t * 4f));
            if (f.pill) {
                int fg = (f.color == theme.accent) ? theme.onAccent : 0xFFFFFFFF;
                drawPill(canvas, f.s, f.x, f.y - cell * 0.8f * easeOutCubic(t), f.size, f.color, fg, a, sc);
            } else {
                text.setShadowLayer(cell * 0.1f, 0, cell * 0.04f, 0x99000000);
                drawT(canvas, f.s, f.x, f.y - cell * 1.4f * easeOutCubic(t), f.size * sc, f.color, a,
                        Paint.Align.CENTER, fontBlack, 0f);
                text.clearShadowLayer();
            }
        }
        canvas.restore();

        if (gameOver && now >= gameOverStart) {
            if (!overSound) { overSound = true; sfx.play(Sfx.OVER); }
            drawGameOver(canvas, now, w, h);
        }
        if (menuOpen) drawMenu(canvas, now, w, h);
        if (loading) drawSplash(canvas, now, w, h);
        postInvalidateOnAnimation();
    }

    private void drawHud(Canvas canvas, long now) {
        float rad = cell * 0.36f, pad = cell * 0.28f;
        float bump = 1f + 0.14f * (float) Math.sin(Math.PI * clamp01((now - bumpStart) / 260f));

        drawClay(canvas, scoreR, rad, theme.card, 255);
        drawT(canvas, "СЧЁТ", scoreR.left + pad, scoreR.top + hudH * 0.34f, cell * 0.24f, theme.sub, 255,
                Paint.Align.LEFT, fontXB, 0.14f);
        drawT(canvas, String.valueOf(Math.round(dispScore)), scoreR.left + pad, scoreR.bottom - hudH * 0.18f,
                cell * 0.74f * bump, theme.text, 255, Paint.Align.LEFT, fontBlack, 0f);

        drawClay(canvas, bestR, rad, theme.card, 255);
        drawT(canvas, "РЕКОРД", bestR.left + pad, bestR.top + hudH * 0.34f, cell * 0.24f, theme.sub, 255,
                Paint.Align.LEFT, fontXB, 0.14f);
        drawT(canvas, String.valueOf(Math.max(best, score)), bestR.left + pad, bestR.bottom - hudH * 0.18f,
                cell * 0.54f, theme.text, 255, Paint.Align.LEFT, fontBlack, 0f);
        float cs = cell * 0.34f;
        canvas.save();
        canvas.translate(bestR.right - pad - cs, bestR.top + hudH * 0.14f);
        canvas.scale(cs, cs);
        paint.setShader(null);
        paint.setColor(0xFFFFC53D);
        paint.setAlpha(255);
        canvas.drawPath(crown, paint);
        canvas.restore();

        drawClay(canvas, pauseR, rad, theme.card, 255);
        float bw = pauseR.width() * 0.13f, bh = pauseR.height() * 0.34f;
        paint.setShader(null);
        paint.setColor(theme.text);
        paint.setAlpha(255);
        rect.set(pauseR.centerX() - bw * 1.7f, pauseR.centerY() - bh / 2f, pauseR.centerX() - bw * 0.55f, pauseR.centerY() + bh / 2f);
        canvas.drawRoundRect(rect, bw * 0.5f, bw * 0.5f, paint);
        rect.set(pauseR.centerX() + bw * 0.55f, pauseR.centerY() - bh / 2f, pauseR.centerX() + bw * 1.7f, pauseR.centerY() + bh / 2f);
        canvas.drawRoundRect(rect, bw * 0.5f, bw * 0.5f, paint);
    }

    private void drawPreview(Canvas canvas, long now) {
        if (dragIdx < 0 || tray[dragIdx] == null) return;
        Piece p = tray[dragIdx];
        int[] t = target(p);
        if (!canPlace(p, t[0], t[1])) return;
        int pulseA = (int) (70 + 70 * (0.5f + 0.5f * Math.sin(now / 130.0)));
        if (p.bomb) {
            for (int dr = -1; dr <= 1; dr++)
                for (int dc = -1; dc <= 1; dc++) {
                    int rr = t[0] + dr, cc = t[1] + dc;
                    if (rr >= 0 && rr < N && cc >= 0 && cc < N)
                        drawFlat(canvas, gridX + cc * cell, gridY + rr * cell, cell, 0xFFFF7A3D, pulseA);
                }
            drawBomb(canvas, gridX + (t[1] + 0.5f) * cell, gridY + (t[0] + 0.5f) * cell, cell, 160);
            return;
        }
        for (int r = 0; r < N; r++)
            for (int c = 0; c < N; c++) tmp[r][c] = grid[r][c] != 0;
        for (int[] cl : p.cells) tmp[t[0] + cl[0]][t[1] + cl[1]] = true;
        boolean[] rf = new boolean[N], cf = new boolean[N];
        for (int i = 0; i < N; i++) {
            rf[i] = true;
            cf[i] = true;
            for (int j = 0; j < N; j++) {
                if (!tmp[i][j]) rf[i] = false;
                if (!tmp[j][i]) cf[i] = false;
            }
        }
        for (int r = 0; r < N; r++)
            for (int c = 0; c < N; c++)
                if (rf[r] || cf[c])
                    drawFlat(canvas, gridX + c * cell, gridY + r * cell, cell, colors[p.color - 1], pulseA);
        for (int[] cl : p.cells)
            drawTile(canvas, gridX + (t[1] + cl[1]) * cell, gridY + (t[0] + cl[0]) * cell, cell, p.color - 1, 120);
    }

    private void drawTray(Canvas canvas, long now) {
        drawClay(canvas, dockR, cell * 0.45f, theme.card, 255);
        float sw = boardW / 3f;
        for (int k = 0; k < 3; k++) {
            float l = gridX + sw * k + cell * 0.12f, r = gridX + sw * (k + 1) - cell * 0.12f;
            cellR.set(l, dockR.top + cell * 0.18f, r, dockR.bottom - cell * 0.22f);
            drawDimple(canvas, cellR, cell * 0.34f);
        }
        for (int i = 0; i < 3; i++) {
            Piece p = tray[i];
            if (p == null || i == dragIdx) continue;
            float base = traySize(p);
            if (i == retIdx) {
                float t = clamp01((now - retStart) / 220f);
                float e = easeOutCubic(t);
                drawPieceCentered(canvas, p, lerp(retX, slotCx(i), e), lerp(retY, trayCy, e),
                        lerp(retSize, base, e), 255, true);
                if (t >= 1f) retIdx = -1;
                continue;
            }
            float t = (now - slotStart[i]) / 450f;
            if (t < 0f) continue;
            float e = easeOutBack(clamp01(t));
            float yo = (1f - easeOutCubic(clamp01(t))) * cell * 2.5f;
            drawPieceCentered(canvas, p, slotCx(i), trayCy + yo, base * e, (int) (255 * clamp01(t * 3f)), true);
        }
        if (dragIdx >= 0 && tray[dragIdx] != null) {
            Piece p = tray[dragIdx];
            float e = easeOutCubic(clamp01((now - dragStart) / 160f));
            float sz = lerp(traySize(p), cell, e);
            float cx = lerp(slotCx(dragIdx), dragX, e);
            float cy = lerp(trayCy, dragY, e) - cell * 1.5f * e;
            drawPieceCentered(canvas, p, cx, cy, sz, 255, true);
        }
    }

    private void drawGameOver(Canvas canvas, long now, int w, int h) {
        float t = clamp01((now - gameOverStart) / 450f);
        canvas.drawColor((((int) (150 * t)) << 24));
        float e = easeOutBack(t);
        float cw = Math.min(w * 0.86f, cell * 7.2f), ch = cell * 6.3f;
        float x = (w - cw) / 2f, y = (h - ch) / 2f;
        canvas.save();
        canvas.scale(0.85f + 0.15f * e, 0.85f + 0.15f * e, w / 2f, h / 2f);
        int a = (int) (255 * t);
        RectF cardR = new RectF(x, y, x + cw, y + ch);
        drawClay(canvas, cardR, cell * 0.55f, theme.card, 255);
        drawT(canvas, "ИГРА ОКОНЧЕНА", w / 2f, y + cell * 1.0f, cell * 0.3f, theme.sub, a, Paint.Align.CENTER, fontXB, 0.16f);
        drawT(canvas, String.valueOf(score), w / 2f, y + cell * 2.85f, cell * 1.7f, theme.text, a, Paint.Align.CENTER, fontBlack, 0f);
        if (newRecord) {
            drawPill(canvas, "Новый рекорд", w / 2f, y + cell * 3.55f, cell * 0.3f, 0xFFFFC53D, 0xFF3A2200, a, 1f);
        } else {
            drawT(canvas, "Рекорд " + best, w / 2f, y + cell * 3.7f, cell * 0.38f, theme.sub, a, Paint.Align.CENTER, fontXB, 0f);
        }
        RectF br = new RectF(x + cell * 0.6f, y + ch - cell * 1.8f, x + cw - cell * 0.6f, y + ch - cell * 0.7f);
        drawClay(canvas, br, cell * 0.42f, theme.accent, 255);
        drawT(canvas, "Играть снова", w / 2f, br.centerY() + cell * 0.15f, cell * 0.42f, theme.onAccent, a, Paint.Align.CENTER, fontXB, 0f);
        canvas.restore();
    }

    private void drawMenu(Canvas canvas, long now, int w, int h) {
        float t = clamp01((now - menuStart) / 240f);
        int a = (int) (255 * t);
        canvas.drawColor((((int) (160 * t)) << 24));
        layoutMenu();
        float sc = 0.9f + 0.1f * easeOutBack(t);
        canvas.save();
        canvas.scale(sc, sc, w / 2f, h / 2f);
        drawClay(canvas, menuCard, cell * 0.55f, theme.card, 255);
        int soft = mix(theme.board, theme.card, 0.4f);
        float rad = cell * 0.4f;

        drawT(canvas, "Пауза", w / 2f, menuCard.top + cell * 1.0f, cell * 0.66f, theme.text, a, Paint.Align.CENTER, fontBlack, 0f);

        drawClay(canvas, menuR[0], rad, theme.accent, 255);
        drawT(canvas, "Продолжить", menuR[0].centerX(), menuR[0].centerY() + cell * 0.15f, cell * 0.42f,
                theme.onAccent, a, Paint.Align.CENTER, fontXB, 0f);

        drawClay(canvas, menuR[1], rad, soft, 255);
        drawT(canvas, "Начать заново", menuR[1].centerX(), menuR[1].centerY() + cell * 0.15f, cell * 0.38f,
                theme.text, a, Paint.Align.CENTER, fontXB, 0f);

        String[] tl = {"ЗВУК", "ВИБРО", "ТЕМА"};
        String[] tv = {soundOn ? "Вкл" : "Выкл", vibeOn ? "Вкл" : "Выкл", theme.name};
        boolean[] on = {soundOn, vibeOn, true};
        for (int k = 0; k < 3; k++) {
            RectF r = menuR[2 + k];
            drawClay(canvas, r, rad, soft, 255);
            drawT(canvas, tl[k], r.centerX(), r.top + cell * 0.55f, cell * 0.2f, theme.sub, a, Paint.Align.CENTER, fontXB, 0.14f);
            drawT(canvas, tv[k], r.centerX(), r.top + cell * 1.1f, cell * 0.38f, theme.text, a, Paint.Align.CENTER, fontXB, 0f);
            if (k < 2) {
                paint.setShader(null);
                paint.setColor(on[k] ? 0xFF38B98A : theme.sub);
                paint.setAlpha(a);
                canvas.drawCircle(r.right - cell * 0.28f, r.top + cell * 0.28f, cell * 0.08f, paint);
            }
        }

        String[] sl = {"Игр", "Линий", "Лучшая серия"};
        int[] sv = {games, totalLines, bestCombo};
        float colW = menuR[0].width() / 3f;
        for (int k = 0; k < 3; k++) {
            float cx = menuR[0].left + colW * (k + 0.5f);
            drawT(canvas, String.valueOf(sv[k]), cx, menuStatsY + cell * 0.6f, cell * 0.6f, theme.text, a,
                    Paint.Align.CENTER, fontBlack, 0f);
            drawT(canvas, sl[k], cx, menuStatsY + cell * 1.0f, cell * 0.24f, theme.sub, a, Paint.Align.CENTER, fontXB, 0f);
        }

        drawT(canvas, "Выйти", menuR[5].centerX(), menuR[5].centerY() + cell * 0.14f, cell * 0.36f,
                theme.sub, a, Paint.Align.CENTER, fontXB, 0f);
        canvas.restore();
    }

    // ---------- loading screen ----------
    private void drawTitle(Canvas canvas, String s, float w, float baseY, float size, int color, float el, float startMs) {
        text.setTypeface(fontBlack);
        text.setTextSize(size);
        text.setLetterSpacing(0f);
        text.setTextAlign(Paint.Align.CENTER);
        float gap = size * 0.06f;
        int n = s.length();
        float[] wd = new float[n];
        float total = 0f;
        for (int i = 0; i < n; i++) {
            wd[i] = text.measureText(String.valueOf(s.charAt(i))) + gap;
            total += wd[i];
        }
        float x = w / 2f - total / 2f;
        for (int i = 0; i < n; i++) {
            float t = (el - startMs - i * 60f) / 380f;
            float cx = x + wd[i] / 2f;
            x += wd[i];
            if (t <= 0f) continue;
            float e = easeOutBack(clamp01(t));
            float rise = (1f - easeOutCubic(clamp01(t))) * size * 0.5f;
            int a = (int) (255 * clamp01(t * 2.5f));
            String ch = String.valueOf(s.charAt(i));
            canvas.save();
            canvas.scale(e, e, cx, baseY - size * 0.35f + rise);
            drawT(canvas, ch, cx, baseY + rise + size * 0.05f, size, mix(color, 0xFF000000, 0.45f), (int) (a * 0.22f),
                    Paint.Align.CENTER, fontBlack, 0f);
            drawT(canvas, ch, cx, baseY + rise, size, color, a, Paint.Align.CENTER, fontBlack, 0f);
            canvas.restore();
        }
    }

    private void drawSplash(Canvas canvas, long now, int w, int h) {
        float el = now - loadStart;
        float fade = loadEnd == 0 ? 0f : clamp01((now - loadEnd) / 450f);
        canvas.saveLayerAlpha(0, 0, w, h, (int) (255 * (1f - fade * fade)));
        float sc = 1f + 0.05f * fade;
        canvas.scale(sc, sc, w / 2f, h / 2f);
        if (bgBmp != null) canvas.drawBitmap(bgBmp, 0, 0, null);
        else canvas.drawColor(theme.bg1);

        // logo: собранный пазл 3x3
        int[][] lay = {{0, 1, 1}, {0, 1, 1}, {0, 0, 3}};
        float ts = cell * 1.3f;
        float ox = w / 2f - ts * 1.5f, oy = h * 0.30f - ts * 1.5f;
        int k = 0;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++, k++) {
                float t = (el - 200f - k * 110f) / 450f;
                if (t <= 0f) continue;
                float e = easeOutBack(clamp01(t));
                float dy = -(1f - easeOutCubic(clamp01(t))) * cell * 3f;
                float wave = el > 1500f ? 0.035f * (float) Math.sin(el / 1000.0 * 5.0 - (r + c) * 0.9) : 0f;
                float sz = ts * e * (1f + wave);
                float cx = ox + (c + 0.5f) * ts, cy = oy + (r + 0.5f) * ts + dy;
                drawTile(canvas, cx - sz / 2f, cy - sz / 2f, sz, lay[r][c], (int) (255 * clamp01(t * 3f)), true);
            }
        }

        drawTitle(canvas, "BLOCK", w, h * 0.51f, cell * 1.15f, theme.text, el, 900f);
        drawTitle(canvas, "PUZZLE", w, h * 0.51f + cell * 1.3f, cell * 1.15f, theme.accent, el, 1200f);
        float sa = clamp01((el - 1700f) / 400f);
        drawT(canvas, "Головоломка из блоков", w / 2f, h * 0.51f + cell * 2.2f, cell * 0.34f, theme.sub,
                (int) (255 * sa), Paint.Align.CENTER, fontXB, 0.04f);

        // прогресс
        float p = easeOutCubic(clamp01(el / 2000f));
        if (!sfx.ready) p = Math.min(p, 0.92f);
        if (loadEnd != 0) p = 1f;
        float bw = boardW * 0.72f, bh = cell * 0.46f, bx = (w - bw) / 2f, by = h * 0.80f;
        RectF track = new RectF(bx, by, bx + bw, by + bh);
        drawDimple(canvas, track, bh / 2f);
        float fw = Math.max(bh, bw * p);
        if (p > 0.02f) {
            RectF fill = new RectF(bx + cell * 0.04f, by + cell * 0.04f, bx + cell * 0.04f + fw - cell * 0.08f, by + bh - cell * 0.04f);
            drawClay(canvas, fill, fill.height() / 2f, theme.accent, 255);
        }
        drawT(canvas, "Загрузка " + (int) (p * 100) + "%", w / 2f, by - cell * 0.3f, cell * 0.3f, theme.sub, 255,
                Paint.Align.CENTER, fontXB, 0.06f);
        float phase = (el % 1800f) / 1800f;
        float ta = phase < 0.15f ? phase / 0.15f : (phase > 0.85f ? (1f - phase) / 0.15f : 1f);
        drawT(canvas, TIPS[((int) (el / 1800f)) % TIPS.length], w / 2f, by + bh + cell * 0.8f, cell * 0.3f,
                theme.sub, (int) (255 * clamp01(ta)), Paint.Align.CENTER, fontXB, 0f);
        canvas.restore();
    }
}
