# Block Puzzle

Стиль интерфейса: Claymorphism (мягкие объёмные "глиняные" формы).
Шрифт: Nunito (SIL Open Font License 1.1, см. app/src/main/assets/fonts/OFL.txt).
Звуки синтезируются в коде (Sfx.java).
