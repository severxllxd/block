# Block Puzzle

Простая игра в стиле Block Blast: перетаскивай фигуры на поле 8x8, собирай полные линии.

Сборка: любой push в main запускает GitHub Actions (вкладка Actions -> Build APK -> Artifacts -> BlockPuzzle-apk).
